MystrixPoints 1.2.1

Cambios del leaderboard:
- Se eliminaron los textos extra debajo del logo.
- Se ajustó el bloque de "TU CLASIFICACIÓN" para alinear mejor la posición y los puntos.
- El leaderboard sigue dibujándose aunque se pulse F1 desde la lógica del mod.
