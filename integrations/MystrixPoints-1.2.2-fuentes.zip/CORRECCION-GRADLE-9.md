# MystrixPoints 1.1.2 — Corrección de Gradle 9.7.1

## Causa

Gradle falla con `:test FAILED` y el mensaje `did not discover any tests to execute`.
Las comprobaciones `DomainSelfTest` y `BoardSnapshotSelfTest` tenían `main()` pero no tests registrados en un framework.

## Corrección

- JUnit Jupiter 5.11.4 y JUnit Platform Launcher declarados en `build.gradle`.
- `test` configurado con `useJUnitPlatform()` sin desactivar `failOnNoDiscoveredTests`.
- Nuevas suites `DomainJUnitTest` y `BoardSnapshotJUnitTest` ejecutan las verificaciones que ya existían.
- Se mantienen los self-tests manuales para pruebas independientes del entorno Fabric.

## Ejecutar en Windows

```powershell
cd E:\TheHunt2\MystrixPoints
.\gradlew.bat --stop
.\gradlew.bat --no-daemon clean build
```

El JAR de producción, una vez construido, se genera en `build/libs/` (normalmente el JAR remapeado sin sufijos `-sources` ni `-dev`).

### Aviso de sqlite-jdbc

`(3.53.4.0) is not valid semver for dependency org.xerial:sqlite-jdbc:3.53.4.0` es una **advertencia de Fabric Loom**, no el fallo que interrumpe el build. La versión de Maven usa cuatro componentes numéricos y Loom espera una versión compatible con SemVer al envolver dependencias no-mod para jar-in-jar. Se conserva la versión oficial de SQLite-JDBC para evitar cambios de dependencia no comprobados.

### Si IntelliJ retiene el caché Loom

Detener la importación/compilación Gradle de IntelliJ, dejar que termine, o cerrar IntelliJ y repetir la compilación. No eliminar archivos `.lock` de procesos activos.

## Limitaciones de comprobación

Las pruebas de dominio pueden ejecutarse con `javac`/`java` independientes del runtime Fabric. En el entorno de generación no se logró ejecutar el Gradle Wrapper completo por falta de acceso a la distribución Gradle, por lo que se debe confirmar el build real en tu PC.
