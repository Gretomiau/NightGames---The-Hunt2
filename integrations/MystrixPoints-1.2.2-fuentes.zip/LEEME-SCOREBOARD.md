# MystrixPoints 1.1.2 — HUD leaderboard Sci-Fi

## Qué se añadió

Integra un HUD estilo The Hunt 2 con las texturas entregadas en `scoreboard.zip`.
No depende del mod binario `template-1.0.0.zip` ni sobrescribe equipos u objetivos del scoreboard vanilla.

- Top 5 GLOBAL, BATTLE ROYALE, FLASHGAME, MYSTRIX POTATO.
- Rango y puntos propios, incluso si el jugador no está en el Top 5.
- El motor de puntos conserva su API pública, SQLite WAL, anti-duplicados, comandos y reseteos offline.
- Sin callback periódico de tick en el servidor para los puntos ni para el HUD.
- El broadcaster agrupa cambios en ventanas de 600 ms, haciendo una consulta de saldos para todos los destinatarios.
- Solo reciben snapshots los clientes que anuncian compatibilidad con el paquete personalizado del mod.
- Cliente completamente visual: los puntos verdaderos se calculan en el servidor.

## Instalación

1. Abrir el proyecto en Windows y compilar con `gradlew.bat --no-daemon clean build`.
2. Si Gradle informa de una dependencia no resuelta, revisar conectividad y versiones de `gradle.properties` antes de instalar.
3. Instalar el **JAR mod** que genere Gradle en `mods/` del servidor Fabric 1.21.1 Java 21.
4. Instalar el **mismo JAR** en `mods/` de cada cliente que necesite ver el HUD. Es un mod universal con inicializadores separados por lado; no requiere que los clientes tengan acceso a SQLite.
5. La base de datos existente es reutilizada. Hacer backup de `config/mystrixpoints/points.sqlite` antes de actualizar.

El ZIP **no contiene un JAR compilado y probado**. Debe compilarse y validarse en Minecraft real.

## Teclas y configuración

- La visibilidad del scoreboard la controla exclusivamente el servidor. **No existe tecla F8 para ocultarlo**.
- F9: alternar global / BattleRoyale / Flashgame / MystrixPotato (se puede reasignar en Controles).
- Ajustar `config/mystrixpoints-hud.json` **en el cliente**:

```json
{
  "scale": 1.0,
  "marginRight": 12,
  "marginTop": 14,
  "defaultScope": "global"
}
```

`scale` tiene límites de 0.55 a 1.65 y se reduce automáticamente si la resolución GUI es pequeña.
El scoreboard no consulta la opción F1 ni la pantalla F3 para decidir su visibilidad. Los menús abiertos pueden cubrirlo por el orden normal de renderizado.

## Archivos nuevos

- `client/LeaderboardHud.java` (renderizado)
- `client/HudClientConfig.java` (configuración visual)
- `client/MystrixPointsClient.java` (inicializador cliente)
- `network/HudSnapshotPayload.java` (protocolo servidor -> cliente)
- `scoreboard/BoardSnapshot.java` (rangos y top 5)
- `scoreboard/ScoreboardPublisher.java` (sincronización por eventos)
- `assets/mystrixpoints/textures/gui/leaderboard/*.png` (texturas compactadas desde el ZIP)
- `src/test/java/com/mystrixstudio/points/BoardSnapshotSelfTest.java`

## Validación local

- `javac --release 21` del motor de puntos y datos de ranking: PASS.
- `DomainSelfTest` y `BoardSnapshotSelfTest`: PASS.
- Compilación sintáctica de cliente/red con interfaces de prueba: PASS.
- Gradle/Fabric runtime: SIN VALIDAR (sin distribución descargable en el entorno de creación).

## Comprobaciones en servidor de pruebas

1. Conectarse con mod cliente; comprobar HUD y posición propia.
2. Conectarse sin mod cliente; comprobar que ningún paquete personalizado lo desconecta.
3. `/points add <jugador> 5`; verificar el HUD actualizado en menos de 2 s.
4. `/points resetall confirm`; verificar la clasificación sin valores antiguos.
5. Probar simultáneamente minijuegos BattleRoyale/Flashgame sin alteraciones en scoreboard de equipos.
6. Verificar que F8 no controla visibilidad, F9 solo alterna ranking y F1 no oculta el panel mientras el HUD se renderiza.

## Control exclusivo del servidor (v1.1.2)

Solo los operadores nivel 4 y la consola pueden ejecutar:

```mcfunction
/points scoreboard showall
/points scoreboard hideall
/points scoreboard status
```

- `showall`: muestra el HUD permanentemente durante el juego. El cliente **no dispone de F8** para ocultarlo.
- `hideall`: oculta el HUD de todos los clientes con el mod. Los jugadores no pueden volver a mostrarlo por su cuenta.
- `status`: consulta la política activa.
- No existe `/points scoreboard release` (se retiró para impedir la visibilidad local).
- Predeterminado: `FORCE_SHOW`. Una configuración antigua `LOCAL` se interpreta como `FORCE_SHOW`.
- La política persiste en `config/mystrixpoints/scoreboard-control.properties`.
- Los clientes que se conecten después reenvían un paquete de preparación para recibir la política vigente.
- Los ajustes de HUD solo permiten cambiar tamaño, márgenes y clasificación, nunca visibilidad.
- Requiere instalar la **versión 1.1.2 tanto en servidor como en clientes**. Un cliente sin el mod no tiene ese HUD y un cliente deliberadamente modificado podría ignorar cualquier HUD personalizado; no es posible impedirlo de manera absoluta desde el servidor.

**Compatibilidad:** No se reemplaza el scoreboard vanilla y no se alteran los equipos de los minijuegos.
