# MystrixPoints 1.1.2 - Visibilidad obligatoria

- `/points scoreboard showall`: fuerza visible en los clientes con MystrixPoints 1.1.2.
- `/points scoreboard hideall`: fuerza oculto en los clientes.
- `/points scoreboard status`: política actual.
- F8 ya no está registrado; se elimina la propiedad local `visible`.
- F9 solo cambia entre categorías del ranking.
- F1/F3 no se comprueban en el render de LeaderboardHud; los menús aún pueden superponer el HUD.
- FORCE_SHOW es valor por defecto y sustituye el antiguo LOCAL.
- Estado persistido; sincronización tanto en JOIN servidor como cuando el cliente anuncia readiness.
- No obliga a instalar el mod: para ver el HUD, el cliente necesita la versión actualizada. Un cliente modificado puede omitir renderizar cualquier interfaz cliente.
- Código fuente para Fabric 1.21.1/Java 21; compilación en Minecraft real pendiente.
