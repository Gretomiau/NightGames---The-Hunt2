# MystrixPoints 1.2.2 — Penalización y corrección SQLite

## Cambios
- Corrige /points remove: nunca usa INSERT con un valor negativo bajo CHECK(points >= 0).
- /points set a un valor inferior también usa un UPDATE seguro.
- Cada muerte real de un jugador (evento ServerLivingEntityEvents.AFTER_DEATH) resta 1 punto global; si tiene 0, permanece en 0.
- Los jugadores espectadores están excluidos; los totems y las transiciones artificiales a spectator NO son muertes reales del evento.
- La resta utiliza prioritariamente los puntos de la categoría admin y después el saldo positivo de mayor tamaño para mantener los balances por minijuego no negativos.
- Las muertes quedan registradas en processed_events y point_ledger de forma transaccional y con identificadores únicos.
- Permanece el leaderboard visual 1.2.1 y su control servidor, incluido F1.

## Construcción
```
.\gradlew.bat --no-daemon clean build
```
**Sustituye el JAR servidor y vuelve a ejecutar el build para generar el JAR cliente.**
Respalda `config/mystrixpoints/points.sqlite*` (base + WAL + SHM) con el servidor parado antes de sustituir el mod. No borres esa base de datos.
