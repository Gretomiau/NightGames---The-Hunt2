# MystrixPoints 1.2.2 — Corrección de descuentos y -1 por muerte

## Qué cambia
- Arreglado `/points remove <jugador> <cantidad>`: el descuento usa `UPDATE ... WHERE points >= ?` en SQLite en vez de intentar insertar un número negativo, lo que causaba `CHECK constraint failed: points >= 0`.
- Arreglado también `/points set <jugador> <cantidad>` si se baja el saldo actual.
- En cada muerte **real** de un jugador, el servidor solicita -1 punto. Si tiene 0, continúa en 0.
- No penaliza a jugadores en espectador ni eventos cancelados de muerte (ej. tótem).
- Todas las operaciones siguen la cola transaccional existente; se anotan en el historial.
- Preserva el leaderboard de la versión 1.2.1 (incluido el renderizado con F1).

## Alcance
La penalización se aplica a las muertes reales que disparan `ServerLivingEntityEvents.AFTER_DEATH`. Si un minijuego elimina artificialmente a un participante al pasarlo a espectador, **sin muerte real**, ese cambio no genera la penalización de muerte, aunque puede seguir dando puntos por kill mediante la API de BattleRoyale.

Se resta del saldo global existente. Para mantener todos los balances no negativos, si hay puntos de administración se descuentan primero; si no, se descuenta del saldo positivo más alto entre los minijuegos. Por tanto, la resta puede afectar también al ranking de ese minijuego.

## Instalación
1. Detén el servidor y haz una copia de seguridad de `config/mystrixpoints/points.sqlite`, `points.sqlite-wal` y `points.sqlite-shm` si existen.
2. Extrae el ZIP fuente a una carpeta de proyecto nueva (o compara los cambios para integrarlos a tu proyecto).
3. Ejecuta `gradlew.bat --no-daemon clean build` en Windows con Java 21.
4. Instala el JAR Fabric remapeado de `build/libs/` en el servidor. No instales el `sources.jar`.
5. Si distribuyes un cliente con HUD y cambias de versión, compila/distribuye el cliente correspondiente.
6. Valida con una cuenta con 1 punto: `/points remove <jugador> 1`. Debe mostrar 0 sin error.
7. Otorga 2 puntos: `/points add <jugador> 2` y muere. Debe quedar 1. Con cero puntos, morir debe mantener cero.

## Validaciones incluidas
- Pruebas JUnit `SqliteDebitJUnitTest`: descuento al último punto, idempotencia del mismo evento de muerte, saldo 0 y descuento de saldo obtenido en un juego.
- Pruebas Java independientes `DomainSelfTest` y `BoardSnapshotSelfTest`.

Este paquete contiene **código fuente**, no JAR ya compilado en un entorno Fabric real. La validación de build completa queda pendiente en Windows.
