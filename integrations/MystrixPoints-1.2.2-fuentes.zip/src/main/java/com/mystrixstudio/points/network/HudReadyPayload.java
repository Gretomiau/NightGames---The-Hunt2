package com.mystrixstudio.points.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** A one-time client readiness signal; carries no player or reward data. */
public record HudReadyPayload() implements CustomPacketPayload {
    public static final Type<HudReadyPayload> TYPE = new Type<>(
        ResourceLocation.fromNamespaceAndPath("mystrixpoints", "hud_ready"));
    public static final StreamCodec<FriendlyByteBuf,HudReadyPayload> CODEC = StreamCodec.of(
        (buffer,payload) -> {}, buffer -> new HudReadyPayload());
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
