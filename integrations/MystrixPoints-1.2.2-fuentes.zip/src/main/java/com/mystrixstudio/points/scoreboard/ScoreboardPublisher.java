package com.mystrixstudio.points.scoreboard;

import com.mystrixstudio.points.network.HudSnapshotPayload;
import com.mystrixstudio.points.storage.SqlitePointsRepository;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;

import java.util.concurrent.*;
import java.util.concurrent.atomic.*;

/** On-change broadcasts, coalesced across bursts of kills. Zero server-tick callbacks. */
public final class ScoreboardPublisher implements AutoCloseable {
    private final MinecraftServer server;
    private final SqlitePointsRepository repository;
    private final Logger log;
    private final ScheduledExecutorService timer = Executors.newSingleThreadScheduledExecutor(job -> {
        Thread thread = new Thread(job,"mystrixpoints-scoreboard-coalescer");
        thread.setDaemon(true);
        return thread;
    });
    private final AtomicBoolean scheduled = new AtomicBoolean();
    private final AtomicLong version = new AtomicLong();
    private volatile boolean closed;

    public ScoreboardPublisher(MinecraftServer server,SqlitePointsRepository repository,Logger log) {
        this.server=server;this.repository=repository;this.log=log;
    }
    public void markDirty() {
        if (closed) return;
        version.incrementAndGet();
        schedule();
    }
    private void schedule() {
        if (closed || !scheduled.compareAndSet(false,true)) return;
        timer.schedule(() -> server.execute(this::refresh), 600, TimeUnit.MILLISECONDS);
    }
    private void refresh() {
        if (closed) { scheduled.set(false);return; }
        long requested=version.get();
        if (server.getPlayerList().getPlayers().stream().noneMatch(
                p -> ServerPlayNetworking.canSend(p,HudSnapshotPayload.TYPE))) {
            scheduled.set(false);
            if (version.get()!=requested) schedule();
            return;
        }
        repository.scoreboardSnapshot().whenComplete((snapshot,error) -> server.execute(() -> {
            if(closed) return;
            if(error!=null) log.error("Could not refresh MystrixPoints HUD",error);
            else for(var player:server.getPlayerList().getPlayers()) {
                if(ServerPlayNetworking.canSend(player,HudSnapshotPayload.TYPE)) {
                    ServerPlayNetworking.send(player,HudSnapshotPayload.forPlayer(snapshot,player.getUUID()));
                }
            }
            scheduled.set(false);
            if(version.get()!=requested) schedule();
        }));
    }
    @Override public void close() {
        closed=true;
        timer.shutdownNow();
    }
}
