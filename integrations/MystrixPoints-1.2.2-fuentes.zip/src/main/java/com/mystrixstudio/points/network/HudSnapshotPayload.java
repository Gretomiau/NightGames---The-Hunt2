package com.mystrixstudio.points.network;

import com.mystrixstudio.points.scoreboard.BoardSnapshot;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

import java.util.*;

/** Small bounded server->client snapshot. Never accepts C2S point mutations. */
public record HudSnapshotPayload(String season, List<Category> categories) implements CustomPacketPayload {
    public static final Type<HudSnapshotPayload> TYPE = new Type<>(
        ResourceLocation.fromNamespaceAndPath("mystrixpoints","hud_snapshot"));
    public static final StreamCodec<FriendlyByteBuf,HudSnapshotPayload> CODEC = StreamCodec.of(
        (buffer,payload)->payload.write(buffer), HudSnapshotPayload::read);
    public static final int MAX_ROWS = 5;
    public record Row(UUID playerId,String name,long score) { }
    public record Category(String id, List<Row> leaders,int ownRank,long ownScore) { }
    public HudSnapshotPayload { categories=List.copyOf(categories); }
    public static HudSnapshotPayload forPlayer(BoardSnapshot snap,UUID viewer) {
        List<Category> categories=new ArrayList<>();
        for (var cat:snap.categories()) {
            List<Row> rows=new ArrayList<>();
            for(var entry:cat.top()) rows.add(new Row(entry.playerId(),entry.playerName(),entry.points()));
            var own=cat.players().get(viewer);
            categories.add(new Category(cat.id(),List.copyOf(rows),own==null?0:own.rank(),own==null?0:own.points()));
        }
        return new HudSnapshotPayload(snap.season(),categories);
    }
    private void write(FriendlyByteBuf buf) {
        buf.writeUtf(season,48);
        buf.writeVarInt(categories.size());
        for(Category cat:categories) {
            buf.writeUtf(cat.id(),32);
            buf.writeVarInt(cat.ownRank());
            buf.writeVarLong(cat.ownScore());
            buf.writeVarInt(cat.leaders().size());
            for(Row row:cat.leaders()) {
                buf.writeUUID(row.playerId());
                buf.writeUtf(row.name(),36);
                buf.writeVarLong(row.score());
            }
        }
    }
    private static HudSnapshotPayload read(FriendlyByteBuf buf) {
        String season=buf.readUtf(48);
        int count=buf.readVarInt();
        if(count<0 || count>4) throw new IllegalArgumentException("Too many HUD categories");
        List<Category> categories=new ArrayList<>(count);
        for(int i=0;i<count;i++) {
            String id=buf.readUtf(32);
            int rank=buf.readVarInt();
            long score=buf.readVarLong();
            int rows=buf.readVarInt();
            if(rank<0 || rows<0 || rows>MAX_ROWS || score<0)
                throw new IllegalArgumentException("Invalid HUD snapshot");
            List<Row> leaders=new ArrayList<>(rows);
            for(int j=0;j<rows;j++) {
                UUID playerId=buf.readUUID();
                String name=buf.readUtf(36);
                long points=buf.readVarLong();
                if(points<0) throw new IllegalArgumentException("Invalid score");
                leaders.add(new Row(playerId,name,points));
            }
            categories.add(new Category(id,List.copyOf(leaders),rank,score));
        }
        return new HudSnapshotPayload(season,categories);
    }
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
