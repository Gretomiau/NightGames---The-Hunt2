package com.mystrixstudio.points.core;

import com.mystrixstudio.points.api.PointsApi.Game;
import java.util.*;

/** All operations are called under the PointsService lock; never touches Minecraft. */
public final class MatchRegistry {
    public static final class Match {
        public final UUID id;
        public final Game game;
        public final Set<UUID> members;
        public final Map<String, Set<UUID>> teams;
        private final Set<UUID> ineligible = new HashSet<>();
        private boolean closing;
        Match(Game game, UUID id, Set<UUID> members, Map<String, Set<UUID>> teams) {
            this.game = game; this.id = id; this.members = members; this.teams = teams;
        }
        public void requireActive() {
            if (closing) throw new IllegalStateException("Match already finished or cancelled: " + id);
        }
        public void requirePlayer(UUID id) {
            if (!members.contains(id) || ineligible.contains(id))
                throw new IllegalArgumentException("Not an eligible match participant: " + id);
        }
        public void close() { closing = true; }
        public void reopen() { closing = false; }
        void disqualify(UUID id) { ineligible.add(id); }
        public boolean eligible(UUID id) { return members.contains(id) && !ineligible.contains(id); }
    }
    private final Map<UUID, Match> sessions = new HashMap<>();
    public Match begin(Game game, UUID id, Set<UUID> participants, Map<String, Set<UUID>> teamInput) {
        Objects.requireNonNull(game); Objects.requireNonNull(id);
        if (participants == null || participants.isEmpty() || participants.contains(null))
            throw new IllegalArgumentException("Invalid participant set");
        if (game == Game.BATTLEROYALE && participants.size() > 140)
            throw new IllegalArgumentException("BattleRoyale allows at most 140 active participants");
        if (participants.size() > 2048) throw new IllegalArgumentException("Participant limit exceeded");
        if (sessions.containsKey(id)) throw new IllegalStateException("Match UUID already registered");
        var members = Set.copyOf(participants);
        var teams = new HashMap<String, Set<UUID>>();
        if (teamInput != null) for (var t : teamInput.entrySet()) {
            if (t.getKey() == null || !t.getKey().matches("[a-zA-Z0-9_-]{1,48}"))
                throw new IllegalArgumentException("Invalid team key");
            var roster = Set.copyOf(t.getValue());
            if (roster.isEmpty() || !members.containsAll(roster))
                throw new IllegalArgumentException("Team contains unregistered members");
            teams.put(t.getKey(), roster);
        }
        if (game == Game.FLASHGAME && teams.isEmpty())
            throw new IllegalArgumentException("Flashgame needs team rosters");
        Match match = new Match(game, id, members, Map.copyOf(teams));
        sessions.put(id, match);
        return match;
    }
    public Match require(UUID id, Game game) {
        var match = sessions.get(id);
        if (match == null || match.game != game) throw new IllegalArgumentException("Unknown match or wrong game");
        match.requireActive();
        return match;
    }
    public void remove(UUID id) { sessions.remove(id); }
    public void cancel(UUID id) { Match m = sessions.remove(id); if (m != null) m.close(); }
    public void invalidateAll() { sessions.values().forEach(Match::close); sessions.clear(); }
    public void invalidateGame(String game) {
        sessions.values().removeIf(m -> {
            if (m.game.id().equals(game)) { m.close(); return true; }
            return false;
        });
    }
    public void invalidatePlayer(UUID player) { sessions.values().forEach(m -> m.disqualify(player)); }
    public void invalidateOnline(Set<UUID> online, boolean resetOnline) {
        sessions.values().forEach(m -> m.members.forEach(u -> {
            if (online.contains(u) == resetOnline) m.disqualify(u);
        }));
    }
}
