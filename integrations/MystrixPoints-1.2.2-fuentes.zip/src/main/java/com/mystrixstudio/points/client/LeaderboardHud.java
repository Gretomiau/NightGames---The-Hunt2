package com.mystrixstudio.points.client;

import com.mystrixstudio.points.network.HudSnapshotPayload;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.PlayerFaceRenderer;
import net.minecraft.resources.ResourceLocation;

import java.util.*;

/**
 * Compact animated leaderboard in the style and proportions of the user's Template.
 * Does not change vanilla objectives or teams; visibility is server-authoritative.
 * All list formatting and animation target updates happen only on packet receipt.
 */
public final class LeaderboardHud {
    private static final int ART_W = 724;
    private static final int ART_H = 134;
    private static final int WHITE = 0xFFEAFBFF;
    private static final int CYAN = 0xFF7DE9FA;
    private static final int GRAY = 0xFF92A6BA;
    private static final String[] SCOPES = {"global", "battleroyale", "flashgame", "mystrixpotato"};
    private static final ResourceLocation LOGO = texture("logo.png");
    private static final ResourceLocation SKULL = texture("skull.png");
    private static final ResourceLocation[] ROWS = {
        texture("row0.png"), texture("row1.png"), texture("row2.png"), texture("row3.png")
    };

    private record ViewRow(UUID playerId, String name, String points, int rank) { }
    private record ViewCategory(String id, List<ViewRow> leaders, String ownRank, String ownPoints) { }
    private record ViewState(String season, Map<String, ViewCategory> categories) { }
    private final Map<String, Map<UUID, AnimatedLeaderboardRow>> animations = new HashMap<>();
    private ViewState data;
    private int scopeIndex;
    private long lastRenderNanos;

    private static ResourceLocation texture(String name) {
        return ResourceLocation.fromNamespaceAndPath("mystrixpoints", "textures/gui/leaderboard/" + name);
    }

    public void setScope(String scope) {
        for (int i = 0; i < SCOPES.length; i++) {
            if (SCOPES[i].equals(scope)) { scopeIndex = i; return; }
        }
        scopeIndex = 0;
    }

    public String scope() { return SCOPES[scopeIndex]; }
    public void nextScope() { scopeIndex = (scopeIndex + 1) % SCOPES.length; lastRenderNanos = 0; }

    /** On-change snapshots; no per-tick data sorting. UUIDs preserve row animation identity. */
    public void update(HudSnapshotPayload snapshot) {
        Map<String, ViewCategory> categories = new LinkedHashMap<>();
        for (HudSnapshotPayload.Category category : snapshot.categories()) {
            List<ViewRow> leaders = new ArrayList<>();
            Map<UUID, AnimatedLeaderboardRow> states = animations.computeIfAbsent(category.id(), key -> new HashMap<>());
            Set<UUID> incoming = new HashSet<>();
            int rank = 0;
            for (HudSnapshotPayload.Row row : category.leaders()) {
                if (rank >= LeaderboardLayout.MAX_ROWS) break;
                rank++;
                if (!incoming.add(row.playerId())) continue;
                leaders.add(new ViewRow(row.playerId(), row.name(), format(row.score()), rank));
                int targetY = LeaderboardLayout.rowY(rank - 1, 2);
                AnimatedLeaderboardRow animation = states.computeIfAbsent(row.playerId(),
                    key -> new AnimatedLeaderboardRow(targetY, 18f, 13f));
                animation.moveTo(LeaderboardLayout.rowY(rank - 1, 2));
            }
            states.keySet().retainAll(incoming);
            categories.put(category.id(), new ViewCategory(category.id(), List.copyOf(leaders),
                category.ownRank() <= 0 ? "Sin posición" : "#" + category.ownRank(),
                format(category.ownScore()) + " pts"));
        }
        animations.keySet().retainAll(categories.keySet());
        data = new ViewState(shorten(snapshot.season(), 20), Map.copyOf(categories));
    }

    public void clear() { data = null; animations.clear(); lastRenderNanos = 0; }

    public void render(GuiGraphics g, HudClientConfig options) {
        ViewState snapshot = data;
        Minecraft minecraft = Minecraft.getInstance();
        if (snapshot == null || minecraft.player == null || minecraft.screen != null) return;
        ViewCategory active = snapshot.categories().get(scope());
        if (active == null) return;

        int visibleRows = Math.min(options.maxRows, active.leaders().size());
        int layoutHeight = LeaderboardLayout.height(visibleRows, options.rowSpacing);
        float scale = LeaderboardLayout.fitScale(options.scale, g.guiWidth(), g.guiHeight(), layoutHeight, options.marginRight);
        if (scale <= 0.05f) return;
        int x = Math.max(2, g.guiWidth() - options.marginRight - Math.round(LeaderboardLayout.WIDTH * scale));
        int y = Math.max(2, (g.guiHeight() - Math.round(layoutHeight * scale)) / 2 + options.offsetY);
        y = Math.min(y, Math.max(2, g.guiHeight() - Math.round(layoutHeight * scale) - 2));

        long now = System.nanoTime();
        float elapsed = lastRenderNanos == 0 ? 0f : Math.max(0f, Math.min(0.05f, (now - lastRenderNanos) / 1_000_000_000f));
        lastRenderNanos = now;

        PoseStack pose = g.pose();
        pose.pushPose();
        pose.translate(x, y, 0);
        pose.scale(scale, scale, 1f);

        // Logo only. No extra subtitle or mode text below the artwork.
        int logoWidth = Math.round(LeaderboardLayout.LOGO_W * options.logoScale);
        int logoHeight = Math.round(LeaderboardLayout.LOGO_H * options.logoScale);
        int logoX = (LeaderboardLayout.WIDTH - logoWidth) / 2;
        g.blit(LOGO, logoX, 0, logoWidth, logoHeight, 0f, 0f, ART_W, ART_H, ART_W, ART_H);

        if (visibleRows == 0) {
            // Original template: no empty/decorative rows when there are no scores.
            pose.popPose();
            return;
        }

        Map<UUID, AnimatedLeaderboardRow> animated = animations.getOrDefault(active.id(), Map.of());
        int startX = (LeaderboardLayout.WIDTH - LeaderboardLayout.ROW_W) / 2;
        for (int index = 0; index < visibleRows; index++) {
            ViewRow item = active.leaders().get(index);
            AnimatedLeaderboardRow anim = animated.get(item.playerId());
            if (anim != null) {
                // Spacing can change without packet updates.
                anim.moveTo(LeaderboardLayout.rowY(index, options.rowSpacing));
                anim.update(elapsed);
            }
            int rowY = Math.round(anim == null ? LeaderboardLayout.rowY(index, options.rowSpacing) : anim.y());
            int rowX = startX + Math.round(anim == null ? 0 : anim.slideX());
            ResourceLocation rowTexture = ROWS[Math.min(index, ROWS.length - 1)];
            g.blit(rowTexture, rowX, rowY, LeaderboardLayout.ROW_W, LeaderboardLayout.ROW_H,
                0f, 0f, ART_W, ART_H, ART_W, ART_H);
            if (options.renderHeads) renderHead(g, minecraft, item.playerId(), rowX + 29, rowY + 9);
            int nameX = rowX + (options.renderHeads ? 45 : 28);
            scaledText(g, item.rank() + ".", rowX + 11, rowY + 11,
                index == 0 ? 0xFFFFD783 : CYAN, options.textScale, false);
            int scorePixels = Math.round(minecraft.font.width(item.points()) * options.textScale);
            int nameAvailable = Math.max(8, rowX + LeaderboardLayout.ROW_W - 8 - scorePixels - 5 - nameX);
            String fitted = fitText(minecraft, item.name(), nameAvailable, options.textScale);
            scaledText(g, fitted, nameX, rowY + 11, WHITE, options.textScale, false);
            scaledRight(g, item.points(), rowX + LeaderboardLayout.ROW_W - 8,
                rowY + 11, WHITE, options.textScale, false);
        }
        int footerY = LeaderboardLayout.rowY(visibleRows, options.rowSpacing) + 6;
        g.blit(SKULL, startX + 3, footerY + 6, 18, 18, 0f, 0f, 128, 128, 128, 128);
        scaledText(g, "TU CLASIFICACIÓN", startX + 26, footerY + 2, CYAN, 0.76f * options.footerScale, true);
        scaledText(g, active.ownRank(), startX + 26, footerY + 15, WHITE, 0.82f * options.footerScale, true);
        scaledRight(g, active.ownPoints(), startX + LeaderboardLayout.ROW_W - 3,
            footerY + 15, WHITE, 0.82f * options.footerScale, true);
        pose.popPose();
    }

    private static void renderHead(GuiGraphics graphics, Minecraft minecraft, UUID playerId, int x, int y) {
        try {
            var connection = minecraft.getConnection();
            var info = connection == null ? null : connection.getPlayerInfo(playerId);
            if (info != null) {
                PlayerFaceRenderer.draw(graphics, info.getSkin().texture(), x, y, 12);
            } else {
                // Offline leader; never do a blocking web skin lookup from the HUD.
                graphics.blit(SKULL, x, y, 12, 12, 0f, 0f, 128, 128, 128, 128);
            }
        } catch (Exception ignored) {
            graphics.blit(SKULL, x, y, 12, 12, 0f, 0f, 128, 128, 128, 128);
        }
    }

    private static void scaledText(GuiGraphics g, String value, int x, int y, int color, float scale, boolean shadow) {
        PoseStack pose = g.pose();
        pose.pushPose();
        pose.translate(x, y, 0);
        pose.scale(scale, scale, 1f);
        g.drawString(Minecraft.getInstance().font, value, 0, 0, color, shadow);
        pose.popPose();
    }

    private static void scaledRight(GuiGraphics g, String value, int right, int y, int color, float scale, boolean shadow) {
        int width = Minecraft.getInstance().font.width(value);
        scaledText(g, value, Math.round(right - width * scale), y, color, scale, shadow);
    }

    private static void centerScaled(GuiGraphics g, String value, int center, int y, int color, float scale, boolean shadow) {
        int width = Minecraft.getInstance().font.width(value);
        scaledText(g, value, Math.round(center - width * scale * 0.5f), y, color, scale, shadow);
    }

    private static String fitText(Minecraft mc, String raw, int maxWidth, float scale) {
        if (mc.font.width(raw) * scale <= maxWidth) return raw;
        String ellipsis = "…";
        int index = raw.length();
        while (index > 0 && mc.font.width(raw.substring(0, index) + ellipsis) * scale > maxWidth) index--;
        return raw.substring(0, index) + ellipsis;
    }

    private static String shorten(String string, int length) {
        return string.length() > length ? string.substring(0, length) : string;
    }

    private static String format(long value) { return String.format(Locale.ROOT, "%,d", value); }
}
