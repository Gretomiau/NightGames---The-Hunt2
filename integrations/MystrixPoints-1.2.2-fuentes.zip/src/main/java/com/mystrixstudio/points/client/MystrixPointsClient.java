package com.mystrixstudio.points.client;

import com.mystrixstudio.points.network.HudReadyPayload;
import com.mystrixstudio.points.network.HudSnapshotPayload;
import com.mystrixstudio.points.network.HudVisibilityPayload;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

/**
 * The server is the only authority that can change the scoreboard visibility.
 * F8 is intentionally NOT registered. Old client config visible=false is ignored.
 */
public final class MystrixPointsClient implements ClientModInitializer {
    private static HudClientConfig config;
    private static final LeaderboardHud hud = new LeaderboardHud();
    private static HudVisibilityPayload.Mode serverMode = HudVisibilityPayload.Mode.FORCE_SHOW;

    @Override public void onInitializeClient() {
        config = HudClientConfig.load();
        hud.setScope(config.defaultScope);
        KeyMapping cycle = KeyBindingHelper.registerKeyBinding(new KeyMapping(
            "key.mystrixpoints.cycle", GLFW.GLFW_KEY_F9, "category.mystrixpoints"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (cycle.consumeClick()) {
                hud.nextScope();
                config.defaultScope = hud.scope();
                config.save();
            }
        });
        ClientPlayNetworking.registerGlobalReceiver(HudSnapshotPayload.TYPE, (payload, context) ->
            context.client().execute(() -> hud.update(payload)));
        ClientPlayNetworking.registerGlobalReceiver(HudVisibilityPayload.TYPE, (payload, context) ->
            context.client().execute(() -> serverMode = payload.mode()));
        // Reliable server-policy replay after client networking channels become available.
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            serverMode = HudVisibilityPayload.Mode.FORCE_SHOW;
            hud.clear();
            if (ClientPlayNetworking.canSend(HudReadyPayload.TYPE)) {
                ClientPlayNetworking.send(new HudReadyPayload());
            }
        });
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            hud.clear();
            serverMode = HudVisibilityPayload.Mode.FORCE_SHOW;
        });
        HudRenderCallback.EVENT.register((graphics, counter) -> {
            // Unlike vanilla's normal HUD, scoreboard visibility is unaffected by F1.
            // Existing menus can cover it; no screen overlay is forcibly added to menus.
            if (serverMode != HudVisibilityPayload.Mode.FORCE_HIDE) {
                hud.render(graphics, config);
            }
        });
    }
}
