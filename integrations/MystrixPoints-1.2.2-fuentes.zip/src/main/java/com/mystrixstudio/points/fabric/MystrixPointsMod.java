package com.mystrixstudio.points.fabric;

import com.mystrixstudio.points.core.PointsService;
import com.mystrixstudio.points.network.HudSnapshotPayload;
import com.mystrixstudio.points.network.HudReadyPayload;
import com.mystrixstudio.points.network.HudVisibilityPayload;
import com.mystrixstudio.points.scoreboard.ScoreboardPublisher;
import com.mystrixstudio.points.scoreboard.GlobalScoreboardControl;
import com.mystrixstudio.points.api.PointsAccess;
import com.mystrixstudio.points.storage.SqlitePointsRepository;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import java.util.UUID;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;

/** Core runs on dedicated server and integrated server, with no client initializer or ticks. */
public final class MystrixPointsMod implements ModInitializer {
    public static final String ID = "mystrixpoints";
    public static final Logger LOGGER = LoggerFactory.getLogger(ID);
    private static volatile PointsService service;
    private static SqlitePointsRepository repository;
    private static ScoreboardPublisher scoreboard;
    private static GlobalScoreboardControl scoreboardControl;

    public static GlobalScoreboardControl scoreboardControl() {
        var result = scoreboardControl;
        if (result == null) throw new IllegalStateException("Scoreboard visibility not started");
        return result;
    }

    public static PointsService service() {
        var result = service;
        if (result == null) throw new IllegalStateException("MystrixPoints not started");
        return result;
    }
    @Override public void onInitialize() {
        PointsCommands.register();
        // Fires only on an actual server-side player death (not on totem saves,
        // fake deaths or manual spectator transitions). No polling and no global tick.
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, damageSource) -> {
            if (!(entity instanceof ServerPlayer player) || player.isSpectator()) return;
            PointsService points = service;
            if (points == null) return;
            UUID playerId = player.getUUID();
            var server = player.getServer();
            // Unique for this confirmed death; the database deduplicates replays of the same ID.
            String eventId = "death:" + UUID.randomUUID();
            points.penalizeDeath(playerId, eventId).whenComplete((result, error) -> {
                if (error != null) {
                    LOGGER.error("Could not subtract death point from {}", playerId, error);
                    return;
                }
                if (result.deducted()) {
                    server.execute(() -> {
                        // The original ServerPlayer may already have been replaced on respawn.
                        ServerPlayer online = server.getPlayerList().getPlayer(playerId);
                        if (online != null) {
                            online.sendSystemMessage(Component.literal(
                                "[MystrixPoints] -1 punto por morir. Total: " + result.globalBalance()));
                        }
                    });
                }
            });
        });
        PayloadTypeRegistry.playS2C().register(HudSnapshotPayload.TYPE,HudSnapshotPayload.CODEC);
        PayloadTypeRegistry.playS2C().register(HudVisibilityPayload.TYPE,HudVisibilityPayload.CODEC);
        PayloadTypeRegistry.playC2S().register(HudReadyPayload.TYPE,HudReadyPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(HudReadyPayload.TYPE, (payload, context) -> {
            // Never trust the client for points. This message only asks to synchronize HUD state.
            context.server().execute(() -> {
                if (scoreboardControl != null) scoreboardControl.sendTo(context.player());
                if (scoreboard != null) scoreboard.markDirty();
            });
        });
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            try {
                repository = new SqlitePointsRepository(FabricLoader.getInstance().getConfigDir().resolve("mystrixpoints/points.sqlite"));
                service = new PointsService(repository);
                scoreboard = new ScoreboardPublisher(server,repository,LOGGER);
                scoreboardControl = new GlobalScoreboardControl(server,
                    FabricLoader.getInstance().getConfigDir().resolve("mystrixpoints/scoreboard-control.properties"),LOGGER);
                repository.setMutationListener(scoreboard::markDirty);
                PointsAccess.install(service);
                LOGGER.info("MystrixPoints started, SQLite WAL enabled");
            } catch (SQLException e) { throw new IllegalStateException("MystrixPoints could not initialize storage",e); }
        });
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            var player = handler.getPlayer();
            var api = service;
            if (scoreboard != null) scoreboard.markDirty();
            if (scoreboardControl != null) scoreboardControl.sendTo(player);
            if (api != null) api.updateName(player.getUUID(), player.getGameProfile().getName())
                .whenComplete((ok, error) -> { if (error != null) LOGGER.error("Could not index player name",error); });
        });
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            PointsAccess.uninstall();
            if(scoreboard!=null){scoreboard.close();scoreboard=null;}
            if(scoreboardControl!=null){scoreboardControl.close();scoreboardControl=null;}
            service = null;
            if (repository != null) { repository.close(); repository = null; }
        });
    }
}
