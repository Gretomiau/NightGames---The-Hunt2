package com.mystrixstudio.points.core;

/** Zero-based placement rewards; a participant gets only ONE category. */
public final class PotatoScoring {
    private PotatoScoring() {}
    public static int score(int position, int size) {
        if (size < 1 || position < 0 || position >= size) throw new IllegalArgumentException("Invalid placement");
        if (position == 0) return 10;
        if (position == 1) return 5;
        if (position == 2) return 3;
        if (position < Math.max(3, (size + 3) / 4)) return 2;
        if (position < Math.max(3, (size + 1) / 2)) return 1;
        return 0;
    }
}
