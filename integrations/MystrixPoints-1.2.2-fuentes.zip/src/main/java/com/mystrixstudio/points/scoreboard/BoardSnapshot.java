package com.mystrixstudio.points.scoreboard;

import java.util.*;

/** Immutable data only; no Minecraft classes or world access. */
public record BoardSnapshot(String season, List<Category> categories) {
    public static final List<String> SCOPES = List.of("global", "battleroyale", "flashgame", "mystrixpotato");
    public BoardSnapshot { categories = List.copyOf(categories); }
    public record Row(UUID playerId, String playerName, long points, int rank) { }
    public record Category(String id, List<Row> top, Map<UUID, Row> players) {
        public Category { top=List.copyOf(top); players=Map.copyOf(players); }
    }
    public Category category(String id) {
        return categories.stream().filter(c -> c.id().equals(id)).findFirst().orElseThrow();
    }
    public static BoardSnapshot fromRows(String season, Collection<BalanceRow> values, int topSize) {
        Map<String, Map<UUID, Mutable>> groups = new LinkedHashMap<>();
        for (String id : SCOPES) groups.put(id, new HashMap<>());
        for (BalanceRow row:values) {
            if (row.points()<0) throw new IllegalArgumentException("Negative stored points");
            merge(groups.get("global"),row);
            Map<UUID,Mutable> game = groups.get(row.game());
            if (game!=null) merge(game,row);
        }
        List<Category> result=new ArrayList<>();
        for (var group:groups.entrySet()) {
            List<Mutable> sorted=new ArrayList<>(group.getValue().values());
            sorted.sort(Comparator.comparingLong((Mutable m)->m.points).reversed()
                .thenComparing(m->m.playerId.toString()));
            List<Row> all=new ArrayList<>();
            for (int i=0;i<sorted.size();i++) {
                Mutable m=sorted.get(i);
                all.add(new Row(m.playerId,m.name,m.points,i+1));
            }
            Map<UUID,Row> indices=new HashMap<>();
            all.forEach(r -> indices.put(r.playerId(),r));
            result.add(new Category(group.getKey(), all.subList(0,Math.min(Math.max(1,topSize),all.size())), indices));
        }
        return new BoardSnapshot(season,result);
    }
    private static void merge(Map<UUID,Mutable> map,BalanceRow row) {
        Mutable entry=map.computeIfAbsent(row.playerId(),
                id -> new Mutable(id,row.playerName(),0));
        entry.points=Math.addExact(entry.points,row.points());
        if (row.playerName()!=null && !row.playerName().isBlank()) entry.name=row.playerName();
    }
    private static final class Mutable {
        final UUID playerId; String name; long points;
        Mutable(UUID playerId,String name,long points) {
            this.playerId=playerId;this.name=name;this.points=points;
        }
    }
    public record BalanceRow(UUID playerId,String playerName,String game,long points) { }
}
