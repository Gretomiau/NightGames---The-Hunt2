package com.mystrixstudio.points.core;

import com.mystrixstudio.points.api.PointsApi;
import com.mystrixstudio.points.storage.SqlitePointsRepository;
import java.util.*;
import java.util.concurrent.*;

/** All session changes and enqueue operations are synchronized to linearize reset vs award submission. */
public final class PointsService implements PointsApi {
    private final MatchRegistry registry = new MatchRegistry();
    private final SqlitePointsRepository store;
    public PointsService(SqlitePointsRepository store) { this.store = Objects.requireNonNull(store); }

    @Override public synchronized CompletionStage<Void> beginMatch(Game game, UUID matchId, Set<UUID> players,
                                                                     Map<String, Set<UUID>> teams) {
        var match = registry.begin(game, matchId, players, teams);
        return store.registerMatch(game.id(), matchId, match.members).whenComplete((ok, ex) -> {
            if (ex != null) synchronized (PointsService.this) { registry.cancel(matchId); }
        });
    }
    @Override public synchronized CompletionStage<AwardResult> battleRoyaleKill(
            UUID matchId, UUID victim, UUID killer, boolean eliminatedToSpectator) {
        if (!eliminatedToSpectator) throw new IllegalArgumentException("Victim not confirmed eliminated to spectator");
        if (Objects.equals(victim, killer)) throw new IllegalArgumentException("Self elimination has no points");
        var match = registry.require(matchId, Game.BATTLEROYALE);
        match.requirePlayer(victim); match.requirePlayer(killer);
        return store.award(Game.BATTLEROYALE.id(), matchId, "kill:" + victim, Map.of(killer, 1L));
    }
    @Override public synchronized CompletionStage<AwardResult> battleRoyaleVictory(UUID matchId, UUID winner) {
        var match = registry.require(matchId, Game.BATTLEROYALE);
        match.requirePlayer(winner);
        match.close();
        return store.award(Game.BATTLEROYALE.id(), matchId, "victory", Map.of(winner, 10L))
                .whenComplete((v, e) -> {
                    synchronized (PointsService.this) {
                        if (e == null) registry.remove(matchId);
                        else match.reopen();
                    }
                });
    }
    @Override public synchronized CompletionStage<AwardResult> flashgameQualified(UUID matchId, String teamId) {
        var match = registry.require(matchId, Game.FLASHGAME);
        var members = match.teams.get(teamId);
        if (members == null) throw new IllegalArgumentException("Unknown team");
        var rewards = new HashMap<UUID, Long>();
        for (var member : members) if (match.eligible(member)) rewards.put(member, 10L);
        if (rewards.isEmpty()) throw new IllegalArgumentException("No eligible team members");
        return store.award(Game.FLASHGAME.id(), matchId, "qualified:" + teamId, rewards);
    }
    @Override public synchronized CompletionStage<AwardResult> potatoFinished(UUID matchId, List<UUID> order) {
        var match = registry.require(matchId, Game.MYSTRIXPOTATO);
        if (order == null || order.size() != match.members.size() || !new HashSet<>(order).equals(match.members))
            throw new IllegalArgumentException("Finish order must contain each original participant exactly once");
        var rewards = new LinkedHashMap<UUID, Long>();
        for (int i = 0; i < order.size(); i++) {
            int score = PotatoScoring.score(i, order.size());
            if (score > 0 && match.eligible(order.get(i))) rewards.put(order.get(i), (long) score);
        }
        if (rewards.isEmpty()) throw new IllegalArgumentException("No eligible finishers");
        match.close();
        return store.award(Game.MYSTRIXPOTATO.id(), matchId, "finished", rewards)
                .whenComplete((v, e) -> {
                    synchronized (PointsService.this) {
                        if (e == null) registry.remove(matchId);
                        else match.reopen();
                    }
                });
    }
    @Override public synchronized CompletionStage<AwardResult> externalAward(String sourceId, String eventId, Map<UUID,Long> recipients) {
        if (sourceId == null || !sourceId.matches("[a-z0-9_-]{1,48}"))
            throw new IllegalArgumentException("Invalid external source ID");
        return store.externalAward(sourceId, eventId, recipients);
    }
    @Override public synchronized void cancelMatch(UUID matchId) { registry.cancel(matchId); }
    @Override public CompletionStage<Long> balance(UUID player) { return store.balance(player, null); }
    @Override public CompletionStage<Long> gameBalance(UUID player, String gameId) { return store.balance(player, gameId); }
    @Override public CompletionStage<List<LeaderboardEntry>> top(String game, int limit) { return store.top(game, limit); }

    /** Called by a single Fabric AFTER_DEATH hook, never by a client. */
    public CompletionStage<SqlitePointsRepository.DeathPenaltyResult> penalizeDeath(UUID player, String eventId) {
        return store.penalizeDeath(player, eventId);
    }

    public CompletionStage<Void> updateName(UUID id, String name) { return store.updateName(id, name); }
    public CompletionStage<UUID> resolve(String nameOrUuid) { return store.resolve(nameOrUuid); }
    public synchronized CompletionStage<Long> adjust(UUID player, String game, String kind, long amount) {
        if (!game.matches("[a-z0-9_-]{1,48}")) throw new IllegalArgumentException("Invalid game");
        if (amount < 0 || amount > 1_000_000_000L) throw new IllegalArgumentException("Amount out of bounds");
        if (!Set.of("add", "remove", "set").contains(kind)) throw new IllegalArgumentException("Invalid operation");
        return store.adjust(player, game, kind, amount);
    }
    public synchronized CompletionStage<Integer> resetPlayer(UUID player) {
        registry.invalidatePlayer(player);
        return store.reset("player", player, null, Set.of());
    }
    public synchronized CompletionStage<Integer> resetAll() {
        registry.invalidateAll();
        return store.reset("all", null, null, Set.of());
    }
    public synchronized CompletionStage<Integer> resetGame(String game) {
        if ("all".equals(game)) return resetAll();
        if (!game.matches("[a-z0-9_-]{1,48}")) throw new IllegalArgumentException("Invalid game");
        registry.invalidateGame(game);
        return store.reset("game", null, game, Set.of());
    }
    public synchronized CompletionStage<Integer> resetPresence(Set<UUID> online, boolean onlineOnly) {
        Set<UUID> snapshot = Set.copyOf(online);
        registry.invalidateOnline(snapshot, onlineOnly);
        return store.reset(onlineOnly ? "online" : "offline", null, null, snapshot);
    }
    public synchronized CompletionStage<Void> newSeason(String id) {
        if (!id.matches("[a-zA-Z0-9_-]{1,48}")) throw new IllegalArgumentException("Invalid season identifier");
        registry.invalidateAll();
        return store.newSeason(id);
    }
    public CompletionStage<String> season() { return store.season(); }
}
