package com.mystrixstudio.points.scoreboard;

import com.mystrixstudio.points.network.HudVisibilityPayload;
import com.mystrixstudio.points.network.HudVisibilityPayload.Mode;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import org.slf4j.Logger;

import java.io.Reader;
import java.io.Writer;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * A single server-side visibility state, distributed to every compatible client.
 * No polling and no server tick event. Admin writes happen on a dedicated I/O worker.
 * Must call setMode on Minecraft's server thread.
 */
public final class GlobalScoreboardControl implements AutoCloseable {
    private final MinecraftServer server;
    private final Logger logger;
    private final Path configFile;
    private final ExecutorService writer = Executors.newSingleThreadExecutor(r -> {
        Thread thread = new Thread(r, "mystrixpoints-visibility-config");
        thread.setDaemon(true);
        return thread;
    });
    private volatile Mode mode;
    private volatile boolean closed;

    public GlobalScoreboardControl(MinecraftServer server, Path configFile, Logger logger) {
        this.server = server;
        this.configFile = configFile;
        this.logger = logger;
        this.mode = load();
    }

    public Mode mode() { return mode; }

    public void setMode(Mode newMode) {
        if (closed) throw new IllegalStateException("Visibility control already stopped");
        if (newMode == null || newMode == Mode.LOCAL) throw new IllegalArgumentException("Only FORCE_SHOW and FORCE_HIDE are allowed");
        if (mode != newMode) {
            mode = newMode;
            writer.execute(() -> persist(newMode));
        }
        // Repeat even if unchanged: an admin can re-send the mode to all clients.
        for (ServerPlayer player : server.getPlayerList().getPlayers()) sendTo(player);
    }

    /** Called for every joining player; everyone receives the authoritative mode. */
    public void sendTo(ServerPlayer player) {
        if (closed) return;
        if (ServerPlayNetworking.canSend(player, HudVisibilityPayload.TYPE)) {
            ServerPlayNetworking.send(player, new HudVisibilityPayload(mode));
        }
    }

    private Mode load() {
        if (!Files.isRegularFile(configFile)) return Mode.FORCE_SHOW;
        Properties p = new Properties();
        try (Reader reader = Files.newBufferedReader(configFile)) {
            p.load(reader);
            // Upgrade old 1.1.1 installations: LOCAL is no longer permitted.
            Mode stored = Mode.valueOf(p.getProperty("mode", "FORCE_SHOW"));
            return stored == Mode.LOCAL ? Mode.FORCE_SHOW : stored;
        } catch (Exception e) {
            logger.warn("Invalid scoreboard visibility config, defaulting to FORCE_SHOW", e);
            return Mode.FORCE_SHOW;
        }
    }

    private void persist(Mode snapshot) {
        Path tmp = configFile.resolveSibling(configFile.getFileName() + ".tmp");
        try {
            Files.createDirectories(configFile.getParent());
            Properties props = new Properties();
            props.setProperty("mode", snapshot.name());
            try (Writer out = Files.newBufferedWriter(tmp)) {
                props.store(out, "MystrixPoints: server-only scoreboard visibility; FORCE_SHOW or FORCE_HIDE");
            }
            try {
                Files.move(tmp, configFile, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(tmp, configFile, StandardCopyOption.REPLACE_EXISTING);
            }
        } catch (Exception e) {
            logger.error("Could not persist global scoreboard visibility: " + snapshot, e);
        }
    }

    @Override public void close() {
        closed = true;
        writer.shutdown();
        try {
            if (!writer.awaitTermination(5, TimeUnit.SECONDS)) {
                logger.warn("Pending scoreboard visibility config write at server shutdown");
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            logger.warn("Interrupted while closing visibility config writer", e);
        }
    }
}
