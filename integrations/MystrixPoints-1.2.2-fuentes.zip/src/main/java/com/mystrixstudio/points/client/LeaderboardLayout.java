package com.mystrixstudio.points.client;

/** Actual layout units modelled on the supplied BetterLeaderboards template. */
public final class LeaderboardLayout {
    public static final int ROW_W = 158;
    public static final int ROW_H = 30;
    public static final int LOGO_W = 180;
    public static final int LOGO_H = 34;
    public static final int HEADER_H = 42;
    public static final int FOOTER_H = 40;
    public static final int WIDTH = LOGO_W;
    public static final int MAX_ROWS = 5;

    private LeaderboardLayout() { }

    public static int rowY(int position, int spacing) {
        return HEADER_H + position * (ROW_H + Math.max(0, spacing));
    }

    public static int height(int visibleRows, int spacing) {
        int count = Math.max(0, Math.min(MAX_ROWS, visibleRows));
        return count == 0 ? HEADER_H : rowY(count, spacing) + FOOTER_H;
    }

    public static float fitScale(float preferred, int screenWidth, int screenHeight,
                                 int actualHeight, int rightMargin) {
        float width = (screenWidth - Math.max(0, rightMargin) - 6f) / WIDTH;
        float height = (screenHeight - 8f) / Math.max(1, actualHeight);
        return Math.max(0f, Math.min(preferred, Math.min(width, height)));
    }
}
