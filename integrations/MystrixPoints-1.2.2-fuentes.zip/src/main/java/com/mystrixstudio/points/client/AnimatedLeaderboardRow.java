package com.mystrixstudio.points.client;

/**
 * Single row transition state. Pure Java; no interaction with Minecraft or a server tick.
 * Identity is the UUID of the player, not the displayed name, so renames and ties are safe.
 */
public final class AnimatedLeaderboardRow {
    private float y;
    private float targetY;
    private float slideX;
    private final float speed;

    public AnimatedLeaderboardRow(float targetY, float entranceOffset, float speed) {
        this.y = targetY;
        this.targetY = targetY;
        this.slideX = Math.max(0f, entranceOffset);
        this.speed = Math.max(1f, speed);
    }

    public void moveTo(float targetY) {
        this.targetY = targetY;
    }

    /** Delta is elapsed render time in seconds, bounded to avoid jumps after alt-tab. */
    public void update(float seconds) {
        float dt = Math.max(0f, Math.min(seconds, 0.05f));
        float factor = 1f - (float) Math.exp(-speed * dt);
        y += (targetY - y) * factor;
        if (Math.abs(targetY - y) < 0.05f) y = targetY;
        slideX += (0f - slideX) * factor;
        if (slideX < 0.05f) slideX = 0f;
    }

    public float y() { return y; }
    public float slideX() { return slideX; }
}
