package com.mystrixstudio.points.api;

import java.util.*;
import java.util.concurrent.CompletionStage;

/** Public trusted-server API. Never expose these methods through client packets. */
public interface PointsApi {
    enum Game { BATTLEROYALE("battleroyale"), FLASHGAME("flashgame"), MYSTRIXPOTATO("mystrixpotato");
        private final String id;
        Game(String id) { this.id = id; }
        public String id() { return id; }
    }
    enum Status { APPLIED, DUPLICATE }
    record AwardResult(Status status, String eventId, int recipients) {}
    record LeaderboardEntry(UUID player, String name, long points) {}

    /** Only verified active participants; no initial spectators. */
    CompletionStage<Void> beginMatch(Game game, UUID matchId, Set<UUID> participants,
                                     Map<String, Set<UUID>> teams);
    /** Call only after BattleRoyale confirms the victim's ELIMINATION and spectator transition. */
    CompletionStage<AwardResult> battleRoyaleKill(UUID matchId, UUID victim, UUID killer,
                                                   boolean eliminatedToSpectator);
    CompletionStage<AwardResult> battleRoyaleVictory(UUID matchId, UUID winner);
    CompletionStage<AwardResult> flashgameQualified(UUID matchId, String teamId);
    /** Complete descending placement order, from winner to last; no awards for cancelled games. */
    CompletionStage<AwardResult> potatoFinished(UUID matchId, List<UUID> finishOrder);
    /** Trusted server mods can award points without owning a minigame match.
     * eventId must be globally stable and unique within the chosen sourceId.
     */
    CompletionStage<AwardResult> externalAward(String sourceId, String eventId, Map<UUID,Long> recipients);
    void cancelMatch(UUID matchId);
    CompletionStage<Long> balance(UUID player);
    CompletionStage<Long> gameBalance(UUID player, String gameId);
    CompletionStage<List<LeaderboardEntry>> top(String gameIdOrNull, int limit);
}
