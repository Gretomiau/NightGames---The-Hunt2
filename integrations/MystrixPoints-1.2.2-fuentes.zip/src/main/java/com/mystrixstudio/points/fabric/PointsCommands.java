package com.mystrixstudio.points.fabric;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mystrixstudio.points.network.HudVisibilityPayload.Mode;
import com.mojang.brigadier.arguments.LongArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import java.util.*;
import java.util.concurrent.*;
import java.util.function.Function;

/** Brigadier commands never perform disk I/O on the Minecraft main thread. */
public final class PointsCommands {
    private PointsCommands() {}
    private static final String[] GAMES = {"battleroyale","flashgame","mystrixpotato","admin"};
    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(Commands.literal("points")
                .executes(ctx -> self(ctx.getSource()))
                .then(Commands.literal("scoreboard").requires(s -> s.hasPermission(4))
                    .then(Commands.literal("showall")
                        .executes(ctx -> setBoardMode(ctx.getSource(), Mode.FORCE_SHOW)))
                    .then(Commands.literal("hideall")
                        .executes(ctx -> setBoardMode(ctx.getSource(), Mode.FORCE_HIDE)))
                    .then(Commands.literal("status")
                        .executes(ctx -> scoreboardStatus(ctx.getSource()))))
                .then(Commands.literal("top")
                    .executes(ctx -> leaderboard(ctx.getSource(),null))
                    .then(Commands.argument("game",StringArgumentType.word())
                        .executes(ctx -> leaderboard(ctx.getSource(),StringArgumentType.getString(ctx,"game")))))
                .then(Commands.literal("get")
                    .then(Commands.argument("player",StringArgumentType.word())
                        .executes(ctx -> lookup(ctx.getSource(),StringArgumentType.getString(ctx,"player")))))
                .then(Commands.literal("season")
                    .executes(ctx -> {
                        future(ctx.getSource(), MystrixPointsMod.service().season(), s -> "Temporada actual: " + s);
                        return 1;
                    })
                    .then(Commands.literal("new").requires(s -> s.hasPermission(4))
                        .then(Commands.argument("id",StringArgumentType.word())
                            .then(Commands.literal("confirm").executes(ctx -> {
                                var source=ctx.getSource();
                                run(source, () -> MystrixPointsMod.service().newSeason(StringArgumentType.getString(ctx,"id")),
                                    ignored -> "Nueva temporada creada y anteriores archivadas");
                                return 1;
                            })))))
                .then(Commands.literal("add").requires(s -> s.hasPermission(4)).then(
                    Commands.argument("player",StringArgumentType.word()).then(
                    Commands.argument("amount",LongArgumentType.longArg(1,1_000_000_000L))
                        .executes(ctx -> adjust(ctx.getSource(),StringArgumentType.getString(ctx,"player"),"add",LongArgumentType.getLong(ctx,"amount"))))))
                .then(Commands.literal("remove").requires(s -> s.hasPermission(4)).then(
                    Commands.argument("player",StringArgumentType.word()).then(
                    Commands.argument("amount",LongArgumentType.longArg(1,1_000_000_000L))
                        .executes(ctx -> adjust(ctx.getSource(),StringArgumentType.getString(ctx,"player"),"remove",LongArgumentType.getLong(ctx,"amount"))))))
                .then(Commands.literal("set").requires(s -> s.hasPermission(4)).then(
                    Commands.argument("player",StringArgumentType.word()).then(
                    Commands.argument("amount",LongArgumentType.longArg(0,1_000_000_000L))
                        .executes(ctx -> adjust(ctx.getSource(),StringArgumentType.getString(ctx,"player"),"set",LongArgumentType.getLong(ctx,"amount"))))))
                .then(Commands.literal("reset").requires(s -> s.hasPermission(4))
                    .then(Commands.argument("player",StringArgumentType.word())
                        .executes(ctx -> resetPlayer(ctx.getSource(),StringArgumentType.getString(ctx,"player")))))
                .then(Commands.literal("resetuuid").requires(s -> s.hasPermission(4))
                    .then(Commands.argument("uuid",StringArgumentType.word())
                        .executes(ctx -> resetPlayer(ctx.getSource(),StringArgumentType.getString(ctx,"uuid")))))
                .then(Commands.literal("resetgame").requires(s -> s.hasPermission(4))
                    .then(Commands.argument("game",StringArgumentType.word())
                        .then(Commands.literal("confirm").executes(ctx -> {
                            run(ctx.getSource(),() -> MystrixPointsMod.service().resetGame(StringArgumentType.getString(ctx,"game")),
                                n -> "Puntuaciones del juego reiniciadas; filas actualizadas: " + n);
                            return 1;
                        }))))
                .then(Commands.literal("resetall").requires(s -> s.hasPermission(4))
                    .then(Commands.literal("confirm").executes(ctx -> {
                        run(ctx.getSource(),() -> MystrixPointsMod.service().resetAll(),n -> "Reinicio global completo; filas: " + n);
                        return 1;
                    })))
                .then(Commands.literal("resetoffline").requires(s -> s.hasPermission(4))
                    .then(Commands.literal("confirm").executes(ctx -> resetPresence(ctx.getSource(),false))))
                .then(Commands.literal("resetonline").requires(s -> s.hasPermission(4))
                    .then(Commands.literal("confirm").executes(ctx -> resetPresence(ctx.getSource(),true))))
            )
        );
    }
    private static void success(CommandSourceStack source,String msg) { source.sendSuccess(() -> Component.literal("[MystrixPoints] " + msg),false); }
    private static void failed(CommandSourceStack source,Throwable ex) {
        while (ex instanceof CompletionException && ex.getCause()!=null) ex=ex.getCause();
        source.sendFailure(Component.literal("[MystrixPoints] " + ex.getMessage()));
    }
    private static <T> void future(CommandSourceStack source,CompletionStage<T> stage,Function<T,String> render) {
        stage.whenComplete((value,error) -> source.getServer().execute(() -> {
            if(error != null) failed(source,error); else success(source,render.apply(value));
        }));
    }
    @FunctionalInterface private interface Operation<T> { CompletionStage<T> execute() throws Exception; }
    private static <T> void run(CommandSourceStack s,Operation<T> op,Function<T,String> out) {
        try { future(s,op.execute(),out); } catch(Exception e) { failed(s,e); }
    }
    private static int setBoardMode(CommandSourceStack source, Mode mode) {
        try {
            MystrixPointsMod.scoreboardControl().setMode(mode);
            success(source, switch(mode) {
                case FORCE_SHOW -> "Scoreboard VISIBLE por orden del servidor (F8 no existe; F1 no lo oculta).";
                case FORCE_HIDE -> "Scoreboard OCULTO por orden del servidor (los jugadores no pueden revertirlo).";
                case LOCAL -> "Estado anterior ya no permitido.";
            });
            return 1;
        } catch (Exception e) { failed(source,e);return 0; }
    }
    private static int scoreboardStatus(CommandSourceStack source) {
        try {
            success(source,"Visibilidad global del scoreboard: " + MystrixPointsMod.scoreboardControl().mode());
            return 1;
        } catch (Exception e) { failed(source,e);return 0; }
    }
    private static int self(CommandSourceStack source) {
        ServerPlayer p = source.getPlayer();
        if(p == null) { source.sendFailure(Component.literal("Uso desde consola: /points get <jugador>")); return 0; }
        future(source,MystrixPointsMod.service().balance(p.getUUID()),n -> "Tienes " + n + " puntos");
        return 1;
    }
    private static int lookup(CommandSourceStack source,String player) {
        MystrixPointsMod.service().resolve(player).whenComplete((id,error) -> source.getServer().execute(() -> {
            if(error != null) failed(source,error);
            else if(id == null) source.sendFailure(Component.literal("Jugador desconocido en la base de datos"));
            else future(source,MystrixPointsMod.service().balance(id),n -> player + ": " + n + " puntos");
        }));
        return 1;
    }
    private static int leaderboard(CommandSourceStack source,String game) {
        future(source,MystrixPointsMod.service().top(game,10),lines -> {
            StringBuilder sb=new StringBuilder(game==null ? "Top global:" : "Top " + game + ":");
            for(int i=0;i<lines.size();i++) {
                var line=lines.get(i);
                sb.append("\n").append(i+1).append(". ").append(line.name()).append(" — ").append(line.points());
            }
            return sb.toString();
        });
        return 1;
    }
    private static int adjust(CommandSourceStack s,String name,String op,long amount) {
        MystrixPointsMod.service().resolve(name).whenComplete((uuid,error) -> s.getServer().execute(() -> {
            if(error!=null) failed(s,error);
            else if(uuid==null) s.sendFailure(Component.literal("Jugador desconocido; entra al servidor una vez o usa su UUID"));
            else run(s,() -> MystrixPointsMod.service().adjust(uuid,"admin",op,amount),value -> name+" ahora tiene "+value+" puntos globales");
        }));
        return 1;
    }
    private static int resetPlayer(CommandSourceStack s,String name) {
        MystrixPointsMod.service().resolve(name).whenComplete((uuid,error) -> s.getServer().execute(() -> {
            if(error!=null) failed(s,error);
            else if(uuid==null) s.sendFailure(Component.literal("Jugador desconocido; usa un UUID válido"));
            else run(s,()->MystrixPointsMod.service().resetPlayer(uuid),n -> "Puntos reiniciados para "+name+" (filas: "+n+")");
        }));
        return 1;
    }
    private static int resetPresence(CommandSourceStack s,boolean onlineOnly) {
        var ids=new HashSet<UUID>();
        for(var player:s.getServer().getPlayerList().getPlayers()) ids.add(player.getUUID());
        run(s,()->MystrixPointsMod.service().resetPresence(ids,onlineOnly),n -> (onlineOnly?"Online":"Offline")+" reiniciados (filas: "+n+")");
        return 1;
    }
}
