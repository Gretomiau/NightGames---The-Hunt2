package com.mystrixstudio.points.api;

/** Lightweight service access shared by compiled minigame adapters. Server-side only. */
public final class PointsAccess {
    private static volatile PointsApi api;
    private PointsAccess() {}
    public static PointsApi get() {
        PointsApi found = api;
        if (found == null) throw new IllegalStateException("MystrixPoints service is not available");
        return found;
    }
    /** Lifecycle hook for MystrixPoints initializer; not for gameplay mods. */
    public static void install(PointsApi service) { api = service; }
    public static void uninstall() { api = null; }
}
