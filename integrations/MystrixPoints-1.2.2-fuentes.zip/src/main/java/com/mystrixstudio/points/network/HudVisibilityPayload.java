package com.mystrixstudio.points.network;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/**
 * Server-controlled visibility for the client-only leaderboard.
 * Legacy LOCAL is interpreted as visible by new clients; the server only uses
 * FORCE_SHOW and FORCE_HIDE. There is no local visibility toggle.
 * Never carries any score or client->server mutation.
 */
public record HudVisibilityPayload(Mode mode) implements CustomPacketPayload {
    public enum Mode {
        LOCAL, FORCE_SHOW, FORCE_HIDE
    }

    public static final Type<HudVisibilityPayload> TYPE = new Type<>(
        ResourceLocation.fromNamespaceAndPath("mystrixpoints", "hud_visibility")
    );

    public static final StreamCodec<FriendlyByteBuf, HudVisibilityPayload> CODEC = StreamCodec.of(
        (buffer, payload) -> buffer.writeByte(payload.mode.ordinal()),
        buffer -> {
            int ordinal = buffer.readUnsignedByte();
            Mode[] modes = Mode.values();
            if (ordinal >= modes.length) throw new IllegalArgumentException("Unknown HUD visibility mode: " + ordinal);
            return new HudVisibilityPayload(modes[ordinal]);
        }
    );

    public HudVisibilityPayload {
        if (mode == null) throw new IllegalArgumentException("mode is required");
    }

    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
