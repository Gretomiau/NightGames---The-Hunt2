package com.mystrixstudio.points.storage;

import com.mystrixstudio.points.api.PointsApi;
import com.mystrixstudio.points.api.PointsApi.AwardResult;
import com.mystrixstudio.points.api.PointsApi.LeaderboardEntry;
import com.mystrixstudio.points.api.PointsApi.Status;

import java.nio.file.*;
import java.sql.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.Supplier;

/** Single writer, independent read connection, durable journal and materialized balances. */
public final class SqlitePointsRepository implements AutoCloseable {
    @FunctionalInterface private interface SqlTask<T> { T run(Connection connection) throws Exception; }
    private final ThreadPoolExecutor writer = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.SECONDS,
        new ArrayBlockingQueue<>(8192), named("mystrix-points-writer"), new ThreadPoolExecutor.AbortPolicy());
    private final ThreadPoolExecutor reader = new ThreadPoolExecutor(1, 1, 0L, TimeUnit.SECONDS,
        new ArrayBlockingQueue<>(512), named("mystrix-points-reader"), new ThreadPoolExecutor.AbortPolicy());
    private final Connection writeConnection;
    private final String url;
    private volatile boolean closed;
    private volatile Runnable mutationListener = () -> {};
    public void setMutationListener(Runnable listener) { this.mutationListener = Objects.requireNonNull(listener); }

    private static ThreadFactory named(String name) { return runnable -> {
        Thread t = new Thread(runnable, name); t.setDaemon(false); return t;
    }; }
    public SqlitePointsRepository(Path file) throws SQLException {
        try { Files.createDirectories(file.toAbsolutePath().getParent()); }
        catch (Exception e) { throw new IllegalStateException("Cannot create points directory", e); }
        url = "jdbc:sqlite:" + file.toAbsolutePath();
        writeConnection = DriverManager.getConnection(url);
        try {
            pragma(writeConnection);
            try (Statement st = writeConnection.createStatement()) {
                st.execute("PRAGMA journal_mode=WAL");
                st.execute("PRAGMA synchronous=FULL");
                st.executeUpdate("CREATE TABLE IF NOT EXISTS players(uuid TEXT PRIMARY KEY, name TEXT NOT NULL)");
                st.executeUpdate("CREATE INDEX IF NOT EXISTS players_name_idx ON players(name COLLATE NOCASE)");
                st.executeUpdate("CREATE TABLE IF NOT EXISTS matches(match_id TEXT PRIMARY KEY, game_id TEXT NOT NULL, active INTEGER NOT NULL, created_at INTEGER NOT NULL)");
                st.executeUpdate("CREATE TABLE IF NOT EXISTS participants(match_id TEXT NOT NULL, uuid TEXT NOT NULL, PRIMARY KEY(match_id,uuid))");
                st.executeUpdate("CREATE TABLE IF NOT EXISTS balances(uuid TEXT NOT NULL, game_id TEXT NOT NULL, points INTEGER NOT NULL DEFAULT 0 CHECK(points >= 0), PRIMARY KEY(uuid, game_id))");
                st.executeUpdate("CREATE INDEX IF NOT EXISTS balances_rank_idx ON balances(game_id,points DESC)");
                st.executeUpdate("CREATE TABLE IF NOT EXISTS processed_events(game_id TEXT NOT NULL, match_id TEXT NOT NULL, event_id TEXT NOT NULL, created_at INTEGER NOT NULL, PRIMARY KEY(game_id,match_id,event_id))");
                st.executeUpdate("CREATE TABLE IF NOT EXISTS point_ledger(id INTEGER PRIMARY KEY AUTOINCREMENT, uuid TEXT NOT NULL, game_id TEXT NOT NULL, match_id TEXT, event_id TEXT NOT NULL, delta INTEGER NOT NULL, created_at INTEGER NOT NULL)");
                st.executeUpdate("CREATE INDEX IF NOT EXISTS ledger_player_idx ON point_ledger(uuid,created_at)");
                st.executeUpdate("CREATE TABLE IF NOT EXISTS reset_audit(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT NOT NULL, scope TEXT NOT NULL, affected INTEGER NOT NULL, created_at INTEGER NOT NULL)");
                st.executeUpdate("CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT NOT NULL)");
                st.executeUpdate("CREATE TABLE IF NOT EXISTS seasons(id TEXT PRIMARY KEY, started_at INTEGER NOT NULL, ended_at INTEGER)");
                st.executeUpdate("CREATE TABLE IF NOT EXISTS archived_balances(season_id TEXT NOT NULL,uuid TEXT NOT NULL, game_id TEXT NOT NULL, points INTEGER NOT NULL,PRIMARY KEY(season_id,uuid,game_id))");
                st.executeUpdate("INSERT OR IGNORE INTO settings(key,value) VALUES('season','season-1')");
                st.executeUpdate("INSERT OR IGNORE INTO seasons(id,started_at) VALUES('season-1',unixepoch())");
            }
        } catch (SQLException e) { try { writeConnection.close(); } catch(SQLException ignored) {} throw e; }
    }
    private static void pragma(Connection c) throws SQLException {
        try (Statement s = c.createStatement()) {
            s.execute("PRAGMA busy_timeout=5000");
            s.execute("PRAGMA foreign_keys=ON");
        }
    }
    private <T> CompletionStage<T> write(SqlTask<T> task) {
        var f = new CompletableFuture<T>();
        if (closed) { f.completeExceptionally(new IllegalStateException("Points database closed")); return f; }
        try { writer.execute(() -> {
            try {
                writeConnection.setAutoCommit(false);
                T val = task.run(writeConnection);
                writeConnection.commit();
                f.complete(val);
                try { mutationListener.run(); } catch (Exception callbackError) {
                    System.err.println("MystrixPoints mutation listener failed: " + callbackError);
                }
            } catch (Exception e) {
                try { writeConnection.rollback(); } catch (SQLException suppressed) { e.addSuppressed(suppressed); }
                f.completeExceptionally(e);
            } finally {
                try { writeConnection.setAutoCommit(true); }
                catch (SQLException e) { System.err.println("MystrixPoints: Failed to restore SQLite autocommit: " + e); }
            }
        }); } catch (RejectedExecutionException e) { f.completeExceptionally(e); }
        return f;
    }
    private <T> CompletionStage<T> read(SqlTask<T> task) {
        var f = new CompletableFuture<T>();
        if (closed) { f.completeExceptionally(new IllegalStateException("Points database closed")); return f; }
        try { reader.execute(() -> {
            try (Connection c = DriverManager.getConnection(url)) {
                pragma(c);
                try (Statement s = c.createStatement()) { s.execute("PRAGMA query_only=ON"); }
                f.complete(task.run(c));
            } catch (Exception e) { f.completeExceptionally(e); }
        }); } catch (RejectedExecutionException e) { f.completeExceptionally(e); }
        return f;
    }
    public CompletionStage<Void> registerMatch(String game, UUID match, Set<UUID> members) {
        return write(c -> {
            try (PreparedStatement s = c.prepareStatement("INSERT OR IGNORE INTO matches(match_id,game_id,active,created_at) VALUES(?,?,1,unixepoch())")) {
                s.setString(1, match.toString()); s.setString(2, game);
                if (s.executeUpdate() != 1) throw new IllegalStateException("Match ID already registered in previous run");
            }
            try (PreparedStatement s = c.prepareStatement("INSERT INTO participants(match_id,uuid) VALUES(?,?)")) {
                for (UUID m : members) { s.setString(1, match.toString()); s.setString(2, m.toString()); s.addBatch(); }
                s.executeBatch();
            }
            return null;
        });
    }
    public CompletionStage<AwardResult> award(String game, UUID match, String eventId, Map<UUID,Long> rewards) {
        if (rewards.isEmpty() || eventId == null || !eventId.matches("[a-zA-Z0-9_:\\-]{1,128}"))
            throw new IllegalArgumentException("Invalid reward event");
        var snapshot = Map.copyOf(rewards);
        if (snapshot.values().stream().anyMatch(v -> v == null || v <= 0 || v > 10))
            throw new IllegalArgumentException("Game reward exceeds configured limit");
        return write(c -> {
            try (PreparedStatement s = c.prepareStatement("SELECT active FROM matches WHERE match_id=? AND game_id=?")) {
                s.setString(1, match.toString()); s.setString(2, game);
                try (ResultSet r = s.executeQuery()) {
                    if (!r.next() || r.getInt(1) != 1) throw new IllegalStateException("Match is not active");
                }
            }
            try (PreparedStatement s = c.prepareStatement("INSERT OR IGNORE INTO processed_events(game_id,match_id,event_id,created_at) VALUES(?,?,?,unixepoch())")) {
                s.setString(1, game); s.setString(2, match.toString()); s.setString(3,eventId);
                if (s.executeUpdate() == 0) return new AwardResult(Status.DUPLICATE, eventId, 0);
            }
            try (PreparedStatement eligible = c.prepareStatement("SELECT 1 FROM participants WHERE match_id=? AND uuid=?");
                 PreparedStatement player = c.prepareStatement("INSERT OR IGNORE INTO players(uuid,name) VALUES(?,?)");
                 PreparedStatement bal = c.prepareStatement("INSERT INTO balances(uuid,game_id,points) VALUES(?,?,?) ON CONFLICT(uuid,game_id) DO UPDATE SET points=points+excluded.points");
                 PreparedStatement led = c.prepareStatement("INSERT INTO point_ledger(uuid,game_id,match_id,event_id,delta,created_at) VALUES(?,?,?,?,?,unixepoch())")) {
                for (var entry : snapshot.entrySet()) {
                    String id = entry.getKey().toString();
                    eligible.setString(1,match.toString()); eligible.setString(2,id);
                    try (ResultSet rs=eligible.executeQuery()) { if (!rs.next()) throw new IllegalArgumentException("Recipient not a match member"); }
                    player.setString(1,id); player.setString(2,id); player.executeUpdate();
                    bal.setString(1,id); bal.setString(2,game); bal.setLong(3,entry.getValue()); bal.executeUpdate();
                    led.setString(1,id); led.setString(2,game); led.setString(3,match.toString()); led.setString(4,eventId);
                    led.setLong(5,entry.getValue()); led.executeUpdate();
                }
            }
            if (eventId.equals("victory") || eventId.equals("finished")) {
                try (PreparedStatement s=c.prepareStatement("UPDATE matches SET active=0 WHERE match_id=?")) {
                    s.setString(1,match.toString()); s.executeUpdate();
                }
            }
            return new AwardResult(Status.APPLIED,eventId,snapshot.size());
        });
    }
    /** Idempotent trusted-mod reward, not bound to a game session. */
    public CompletionStage<AwardResult> externalAward(String game,String eventId,Map<UUID,Long> rewards) {
        if (eventId == null || !eventId.matches("[a-zA-Z0-9_:\\-]{1,128}") || rewards == null
                || rewards.isEmpty() || rewards.size()>2048)
            throw new IllegalArgumentException("Invalid external award");
        var copy=Map.copyOf(rewards);
        if(copy.values().stream().anyMatch(v -> v<=0 || v>10_000))
            throw new IllegalArgumentException("External awards must be between 1 and 10000 points per recipient");
        return write(c -> {
            try(PreparedStatement event=c.prepareStatement("INSERT OR IGNORE INTO processed_events(game_id,match_id,event_id,created_at) VALUES(?,'external',?,unixepoch())")) {
                event.setString(1,game);event.setString(2,eventId);
                if(event.executeUpdate()==0) return new AwardResult(Status.DUPLICATE,eventId,0);
            }
            try(PreparedStatement player=c.prepareStatement("INSERT OR IGNORE INTO players(uuid,name) VALUES(?,?)");
                PreparedStatement balance=c.prepareStatement("INSERT INTO balances(uuid,game_id,points) VALUES(?,?,?) ON CONFLICT(uuid,game_id) DO UPDATE SET points=points+excluded.points");
                PreparedStatement ledger=c.prepareStatement("INSERT INTO point_ledger(uuid,game_id,match_id,event_id,delta,created_at) VALUES(?,?,NULL,?,?,unixepoch())")) {
                for(var entry:copy.entrySet()) {
                    String uuid=entry.getKey().toString();
                    player.setString(1,uuid);player.setString(2,uuid);player.executeUpdate();
                    balance.setString(1,uuid);balance.setString(2,game);balance.setLong(3,entry.getValue());balance.executeUpdate();
                    ledger.setString(1,uuid);ledger.setString(2,game);ledger.setString(3,eventId);ledger.setLong(4,entry.getValue());ledger.executeUpdate();
                }
            }
            return new AwardResult(Status.APPLIED,eventId,copy.size());
        });
    }
    /** Rebuild all four boards from a single asynchronous query. No per-player database queries. */
    public CompletionStage<com.mystrixstudio.points.scoreboard.BoardSnapshot> scoreboardSnapshot() {
        return read(c -> {
            String season = "season-1";
            try(Statement st=c.createStatement();ResultSet rs=st.executeQuery(
                    "SELECT value FROM settings WHERE key='season'")) {
                if(rs.next()) season=rs.getString(1);
            }
            var rows = new ArrayList<com.mystrixstudio.points.scoreboard.BoardSnapshot.BalanceRow>();
            try(Statement st=c.createStatement();ResultSet rs=st.executeQuery(
                    "SELECT b.uuid,COALESCE(p.name,b.uuid),b.game_id,b.points " +
                    "FROM balances b LEFT JOIN players p ON p.uuid=b.uuid")) {
                while(rs.next()) rows.add(new com.mystrixstudio.points.scoreboard.BoardSnapshot.BalanceRow(
                    UUID.fromString(rs.getString(1)),rs.getString(2),rs.getString(3),rs.getLong(4)));
            }
            return com.mystrixstudio.points.scoreboard.BoardSnapshot.fromRows(season,rows,5);
        });
    }
    public CompletionStage<Void> updateName(UUID id, String name) {
        String clipped = name == null ? "" : name.substring(0, Math.min(16, name.length()));
        if (!clipped.matches("[a-zA-Z0-9_]{1,16}")) throw new IllegalArgumentException("Invalid player name");
        return write(c -> {
            try(PreparedStatement s=c.prepareStatement("INSERT INTO players(uuid,name) VALUES(?,?) ON CONFLICT(uuid) DO UPDATE SET name=excluded.name")) {
                s.setString(1,id.toString()); s.setString(2,clipped); s.executeUpdate();
            }
            return null;
        });
    }
    public CompletionStage<UUID> resolve(String text) {
        try { return CompletableFuture.completedFuture(UUID.fromString(text)); }
        catch (IllegalArgumentException ignored) { }
        return read(c -> {
            try (PreparedStatement s=c.prepareStatement("SELECT uuid FROM players WHERE name=? COLLATE NOCASE LIMIT 2")) {
                s.setString(1,text);
                try(ResultSet rs=s.executeQuery()) {
                    if(!rs.next()) return null;
                    UUID first=UUID.fromString(rs.getString(1));
                    if(rs.next()) throw new IllegalArgumentException("Multiple past players share this name; use UUID");
                    return first;
                }
            }
        });
    }
    public CompletionStage<Long> balance(UUID id,String game) {
        return read(c -> {
            String sql = game == null ? "SELECT COALESCE(SUM(points),0) FROM balances WHERE uuid=?"
                    : "SELECT COALESCE(SUM(points),0) FROM balances WHERE uuid=? AND game_id=?";
            try(PreparedStatement s=c.prepareStatement(sql)) {
                s.setString(1,id.toString()); if(game != null) s.setString(2,game);
                try(ResultSet rs=s.executeQuery()) { return rs.next() ? rs.getLong(1) : 0L; }
            }
        });
    }
    public CompletionStage<List<LeaderboardEntry>> top(String game,int limit) {
        int safe = Math.max(1,Math.min(100,limit));
        return read(c -> {
            String sql = "SELECT b.uuid,COALESCE(p.name,b.uuid),SUM(b.points) AS total FROM balances b LEFT JOIN players p ON b.uuid=p.uuid "
                    + (game==null ? "" : "WHERE b.game_id=? ")
                    + "GROUP BY b.uuid ORDER BY total DESC,b.uuid ASC LIMIT ?";
            var output = new ArrayList<LeaderboardEntry>();
            try(PreparedStatement s=c.prepareStatement(sql)) {
                int idx=1; if(game!=null) s.setString(idx++,game); s.setInt(idx,safe);
                try(ResultSet rs=s.executeQuery()) { while(rs.next()) output.add(new LeaderboardEntry(UUID.fromString(rs.getString(1)),rs.getString(2),rs.getLong(3))); }
            }
            return List.copyOf(output);
        });
    }
    /**
     * SQLite checks INSERT values before resolving UPSERT conflicts. An INSERT with -1
     * violates CHECK(points >= 0) even if the existing row has enough points.
     * Credit with UPSERT; debit with a guarded UPDATE. Both run inside writer transaction.
     */
    private static void applyBalanceDelta(Connection c, String playerId, String gameId, long delta) throws SQLException {
        if (delta == 0) return;
        if (delta > 0) {
            try (PreparedStatement s = c.prepareStatement(
                    "INSERT INTO balances(uuid,game_id,points) VALUES(?,?,?) " +
                    "ON CONFLICT(uuid,game_id) DO UPDATE SET points=points+excluded.points")) {
                s.setString(1, playerId);
                s.setString(2, gameId);
                s.setLong(3, delta);
                s.executeUpdate();
            }
        } else {
            long amount = Math.negateExact(delta);
            try (PreparedStatement s = c.prepareStatement(
                    "UPDATE balances SET points=points-? WHERE uuid=? AND game_id=? AND points>=?")) {
                s.setLong(1, amount);
                s.setString(2, playerId);
                s.setString(3, gameId);
                s.setLong(4, amount);
                if (s.executeUpdate() != 1) {
                    throw new IllegalStateException("Insufficient game balance while applying debit: " + gameId);
                }
            }
        }
    }

    /** Death is charged against a positive bucket, never below zero. */
    public record DeathPenaltyResult(boolean deducted, long globalBalance) { }

    /**
     * Apply exactly one point of GLOBAL death penalty for a unique death event.
     * One real death is represented by a stable event ID generated by the death hook.
     * A duplicate event, or a death at zero, never creates a negative balance.
     */
    public CompletionStage<DeathPenaltyResult> penalizeDeath(UUID playerId, String eventId) {
        Objects.requireNonNull(playerId, "playerId");
        if (eventId == null || !eventId.matches("[a-zA-Z0-9_:\\-]{1,128}")) {
            throw new IllegalArgumentException("Invalid death event ID");
        }
        return write(c -> {
            String uid = playerId.toString();
            try (PreparedStatement add = c.prepareStatement(
                    "INSERT OR IGNORE INTO players(uuid,name) VALUES(?,?)")) {
                add.setString(1, uid);
                add.setString(2, uid);
                add.executeUpdate();
            }
            boolean fresh;
            try (PreparedStatement marker = c.prepareStatement(
                    "INSERT OR IGNORE INTO processed_events(game_id,match_id,event_id,created_at) " +
                    "VALUES('system','death',?,unixepoch())")) {
                marker.setString(1, eventId);
                fresh = marker.executeUpdate() == 1;
            }
            boolean deducted = false;
            if (fresh) {
                // Prefer administrator-granted points, then the highest nonzero bucket.
                // All balances retain CHECK(points >= 0), and sum(global) decreases by one.
                String bucket = null;
                try (PreparedStatement find = c.prepareStatement(
                        "SELECT game_id FROM balances WHERE uuid=? AND points>0 " +
                        "ORDER BY CASE WHEN game_id='admin' THEN 0 ELSE 1 END, " +
                        "points DESC, game_id ASC LIMIT 1")) {
                    find.setString(1, uid);
                    try (ResultSet rs = find.executeQuery()) {
                        if (rs.next()) bucket = rs.getString(1);
                    }
                }
                if (bucket != null) {
                    applyBalanceDelta(c, uid, bucket, -1L);
                    try (PreparedStatement ledger = c.prepareStatement(
                            "INSERT INTO point_ledger(uuid,game_id,match_id,event_id,delta,created_at) " +
                            "VALUES(?,?,NULL,?,-1,unixepoch())")) {
                        ledger.setString(1, uid);
                        ledger.setString(2, bucket);
                        ledger.setString(3, "death:" + eventId);
                        ledger.executeUpdate();
                    }
                    deducted = true;
                }
            }
            long total;
            try (PreparedStatement sum = c.prepareStatement(
                    "SELECT COALESCE(SUM(points),0) FROM balances WHERE uuid=?")) {
                sum.setString(1, uid);
                try (ResultSet rs = sum.executeQuery()) {
                    total = rs.next() ? rs.getLong(1) : 0L;
                }
            }
            return new DeathPenaltyResult(deducted, total);
        });
    }

    /** Admin add/remove/set operates on the GLOBAL total, not only an isolated bucket. */
    public CompletionStage<Long> adjust(UUID id,String game,String kind,long amount) {
        return write(c -> {
            String uid = id.toString();
            try (PreparedStatement s=c.prepareStatement("INSERT OR IGNORE INTO players(uuid,name) VALUES(?,?)")) {
                s.setString(1,uid); s.setString(2,uid); s.executeUpdate();
            }
            var scores = new LinkedHashMap<String,Long>();
            try (PreparedStatement s=c.prepareStatement("SELECT game_id,points FROM balances WHERE uuid=?")) {
                s.setString(1,uid);
                try (ResultSet r=s.executeQuery()) { while(r.next()) scores.put(r.getString(1),r.getLong(2)); }
            }
            long current=0;
            for(long v:scores.values()) current=Math.addExact(current,v);
            long target=switch(kind) {
                case "add" -> Math.addExact(current,amount);
                case "remove" -> Math.max(0,current-amount);
                case "set" -> amount;
                default -> throw new IllegalArgumentException("Invalid kind");
            };
            long left=Math.max(0,current-target);
            var diffs=new LinkedHashMap<String,Long>();
            if (target>current) diffs.put("admin",target-current);
            else for (var e:scores.entrySet()) {
                if (left==0) break;
                long take=Math.min(left,e.getValue());
                if(take>0) { diffs.put(e.getKey(),-take); left-=take; }
            }
            try (PreparedStatement ledger=c.prepareStatement(
                    "INSERT INTO point_ledger(uuid,game_id,match_id,event_id,delta,created_at) " +
                    "VALUES(?,?,NULL,?,?,unixepoch())")) {
                for (var d : diffs.entrySet()) {
                    applyBalanceDelta(c, uid, d.getKey(), d.getValue());
                    ledger.setString(1,uid);
                    ledger.setString(2,d.getKey());
                    ledger.setString(3,"admin:" + kind);
                    ledger.setLong(4,d.getValue());
                    ledger.executeUpdate();
                }
            }
            return target;
        });
    }
    public CompletionStage<Integer> reset(String kind,UUID player,String game,Set<UUID> online) {
        return write(c -> {
            String sql = switch (kind) {
                case "player" -> "UPDATE balances SET points=0 WHERE uuid=?";
                case "game" -> "UPDATE balances SET points=0 WHERE game_id=?";
                case "all" -> "UPDATE balances SET points=0";
                case "online","offline" -> null;
                default -> throw new IllegalArgumentException("Unknown reset scope");
            };
            int changed;
            if (sql != null) {
                try(PreparedStatement s=c.prepareStatement(sql)) {
                    if (kind.equals("player")) s.setString(1,player.toString());
                    if (kind.equals("game")) s.setString(1,game);
                    changed=s.executeUpdate();
                }
            } else {
                int total=0;
                try(PreparedStatement s=c.prepareStatement("SELECT DISTINCT uuid FROM balances");
                    ResultSet rs=s.executeQuery()) {
                    var targets=new ArrayList<String>();
                    while(rs.next()) {
                        String uid=rs.getString(1);
                        if(online.contains(UUID.fromString(uid)) == kind.equals("online")) targets.add(uid);
                    }
                    try(PreparedStatement u=c.prepareStatement("UPDATE balances SET points=0 WHERE uuid=?")) {
                        for(String uid:targets) { u.setString(1,uid); total+=u.executeUpdate(); }
                    }
                }
                changed=total;
            }
            if (kind.equals("all") || kind.equals("game")) {
                String stmt=kind.equals("all")?"UPDATE matches SET active=0":"UPDATE matches SET active=0 WHERE game_id=?";
                try(PreparedStatement s=c.prepareStatement(stmt)) {
                    if(kind.equals("game")) s.setString(1,game); s.executeUpdate();
                }
            }
            try(PreparedStatement s=c.prepareStatement("INSERT INTO reset_audit(kind,scope,affected,created_at) VALUES(?,?,?,unixepoch())")) {
                s.setString(1,kind); s.setString(2,kind.equals("player")?player.toString():kind.equals("game")?game:"all players in scope");
                s.setInt(3,changed); s.executeUpdate();
            }
            return changed;
        });
    }
    public CompletionStage<Void> newSeason(String id) {
        return write(c -> {
            String current;
            try(PreparedStatement s=c.prepareStatement("SELECT value FROM settings WHERE key='season'");ResultSet rs=s.executeQuery()) {
                current=rs.next()?rs.getString(1):"season-1";
            }
            try(PreparedStatement s=c.prepareStatement("INSERT INTO seasons(id,started_at) VALUES(?,unixepoch())")) {
                s.setString(1,id); s.executeUpdate();
            }
            try(PreparedStatement s=c.prepareStatement("INSERT INTO archived_balances(season_id,uuid,game_id,points) SELECT ?,uuid,game_id,points FROM balances")) {
                s.setString(1,current); s.executeUpdate();
            }
            try(PreparedStatement s=c.prepareStatement("UPDATE seasons SET ended_at=unixepoch() WHERE id=?")) {
                s.setString(1,current); s.executeUpdate();
            }
            try(Statement s=c.createStatement()) { s.executeUpdate("UPDATE balances SET points=0");s.executeUpdate("UPDATE matches SET active=0"); }
            try(PreparedStatement s=c.prepareStatement("UPDATE settings SET value=? WHERE key='season'")) {
                s.setString(1,id); s.executeUpdate();
            }
            try(PreparedStatement s=c.prepareStatement("INSERT INTO reset_audit(kind,scope,affected,created_at) VALUES('season',?,0,unixepoch())")) {
                s.setString(1,id); s.executeUpdate();
            }
            return null;
        });
    }
    public CompletionStage<String> season() {
        return read(c -> {
            try(Statement s=c.createStatement();ResultSet r=s.executeQuery("SELECT value FROM settings WHERE key='season'")) {
                return r.next()?r.getString(1):"season-1";
            }
        });
    }
    @Override public void close() {
        closed=true;
        writer.shutdown(); reader.shutdown();
        try {
            if (!writer.awaitTermination(15,TimeUnit.SECONDS)) throw new IllegalStateException("SQLite writer did not drain; shutdown aborted");
            reader.awaitTermination(5,TimeUnit.SECONDS);
            try(Statement s=writeConnection.createStatement()) { s.execute("PRAGMA wal_checkpoint(TRUNCATE)"); }
            writeConnection.close();
        } catch (InterruptedException e) { Thread.currentThread().interrupt();throw new IllegalStateException("Interrupted closing points database",e); }
        catch(SQLException e) { throw new IllegalStateException("Unable to close points database",e); }
    }
}
