package com.mystrixstudio.points.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Cosmetic settings only. No local visibility control: the server owns show/hide. */
public final class HudClientConfig {
    public float scale = 0.78f;
    public float logoScale = 1.0f;
    public float textScale = 0.84f;
    public float footerScale = 1.0f;
    public int rowSpacing = 2;
    public int maxRows = 5;
    public int marginRight = 8;
    public int offsetY = 0;
    public boolean renderHeads = true;
    public String defaultScope = "global";
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("mystrixpoints-hud.json");

    public static HudClientConfig load() {
        HudClientConfig value = new HudClientConfig();
        try {
            if (Files.exists(FILE)) {
                String json = Files.readString(FILE);
                HudClientConfig stored = GSON.fromJson(json, HudClientConfig.class);
                if (stored != null) {
                    value = stored;
                    // Auto-migrate the oversized 1.1.x HUD default once.
                    if (json.contains("\"marginTop\"")) value.scale = Math.min(value.scale, 0.78f);
                }
            }
        } catch (Exception ignored) { }
        // Migrate older version's overly large default scale=1.0.
        // The new compact layout is 180x~258, not the old 252x343 overlay.
        value.scale = clamp(value.scale, 0.4f, 1.0f);
        value.logoScale = clamp(value.logoScale, 0.45f, 1.15f);
        value.textScale = clamp(value.textScale, 0.6f, 1f);
        value.footerScale = clamp(value.footerScale, 0.6f, 1.2f);
        value.rowSpacing = Math.max(0, Math.min(12, value.rowSpacing));
        value.maxRows = Math.max(1, Math.min(5, value.maxRows));
        value.marginRight = Math.max(0, Math.min(100, value.marginRight));
        value.offsetY = Math.max(-200, Math.min(200, value.offsetY));
        if (value.defaultScope == null) value.defaultScope = "global";
        value.save();
        return value;
    }

    private static float clamp(float x, float lo, float hi) {
        return Float.isFinite(x) ? Math.max(lo, Math.min(hi, x)) : lo;
    }

    public void save() {
        try {
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(this));
        } catch (Exception ignored) { }
    }
}
