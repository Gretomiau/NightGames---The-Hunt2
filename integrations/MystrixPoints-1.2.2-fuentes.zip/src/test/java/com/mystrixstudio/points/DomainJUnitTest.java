package com.mystrixstudio.points;

import org.junit.jupiter.api.Test;

/** Runs the dependency-free domain regression suite during `gradlew test`. */
final class DomainJUnitTest {
    @Test
    void validatesSurvivalScoringAndMatchRules() {
        DomainSelfTest.main(new String[0]);
    }
}
