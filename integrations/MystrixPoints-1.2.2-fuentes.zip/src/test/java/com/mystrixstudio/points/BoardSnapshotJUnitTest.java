package com.mystrixstudio.points;

import org.junit.jupiter.api.Test;

/** Runs the leaderboard regression suite during `gradlew test`. */
final class BoardSnapshotJUnitTest {
    @Test
    void aggregatesPerGameAndGlobalRankings() {
        BoardSnapshotSelfTest.main(new String[0]);
    }
}
