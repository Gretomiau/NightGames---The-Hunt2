package com.mystrixstudio.points;

import com.mystrixstudio.points.storage.SqlitePointsRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Path;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

/** Runs against the real bundled Xerial SQLite driver via Gradle. */
public class SqliteDebitJUnitTest {
    @TempDir Path tempDir;

    @Test void removingLastPointAndClampingToZeroNeverViolatesSqliteCheck() throws Exception {
        try (var repo = new SqlitePointsRepository(tempDir.resolve("debit.sqlite"))) {
            UUID id = UUID.randomUUID();
            assertEquals(1L, repo.adjust(id,"admin","add",1L).toCompletableFuture().join());
            assertEquals(0L, repo.adjust(id,"admin","remove",1L).toCompletableFuture().join());
            assertEquals(0L, repo.adjust(id,"admin","remove",1L).toCompletableFuture().join());
            assertEquals(3L, repo.adjust(id,"admin","set",3L).toCompletableFuture().join());
            assertEquals(1L, repo.adjust(id,"admin","remove",2L).toCompletableFuture().join());
            assertEquals(0L, repo.adjust(id,"admin","set",0L).toCompletableFuture().join());
            assertEquals(0L, repo.balance(id,null).toCompletableFuture().join());
        }
    }

    @Test void deathPenaltyIsAtMostOneAndEventIdIsIdempotent() throws Exception {
        try (var repo = new SqlitePointsRepository(tempDir.resolve("death.sqlite"))) {
            UUID id = UUID.randomUUID();
            String death1 = "death:" + UUID.randomUUID();
            assertEquals(0L, repo.penalizeDeath(id,death1).toCompletableFuture().join().globalBalance());
            assertFalse(repo.penalizeDeath(id,death1).toCompletableFuture().join().deducted());

            repo.adjust(id,"admin","add",2).toCompletableFuture().join();
            // A duplicate event at zero must not charge points awarded later.
            assertFalse(repo.penalizeDeath(id,death1).toCompletableFuture().join().deducted());
            String death2 = "death:" + UUID.randomUUID();
            assertTrue(repo.penalizeDeath(id,death2).toCompletableFuture().join().deducted());
            assertEquals(1L, repo.balance(id,null).toCompletableFuture().join());
            assertFalse(repo.penalizeDeath(id,death2).toCompletableFuture().join().deducted());
            assertEquals(1L, repo.balance(id,null).toCompletableFuture().join());
            assertTrue(repo.penalizeDeath(id,"death:"+UUID.randomUUID()).toCompletableFuture().join().deducted());
            assertEquals(0L, repo.balance(id,null).toCompletableFuture().join());
            assertFalse(repo.penalizeDeath(id,"death:"+UUID.randomUUID()).toCompletableFuture().join().deducted());
            assertEquals(0L, repo.balance(id,null).toCompletableFuture().join());
        }
    }

    @Test void deathCanDebitEarnedGameBucketWithoutNegativePoints() throws Exception {
        try (var repo = new SqlitePointsRepository(tempDir.resolve("match.sqlite"))) {
            UUID user = UUID.randomUUID();
            UUID match = UUID.randomUUID();
            repo.registerMatch("battleroyale",match,java.util.Set.of(user)).toCompletableFuture().join();
            repo.award("battleroyale",match,"victory",java.util.Map.of(user,10L))
                .toCompletableFuture().join();
            assertTrue(repo.penalizeDeath(user,"death:"+UUID.randomUUID()).toCompletableFuture().join().deducted());
            assertEquals(9L,repo.balance(user,null).toCompletableFuture().join());
            assertEquals(9L,repo.balance(user,"battleroyale").toCompletableFuture().join());
        }
    }
}
