package com.mystrixstudio.points;

import com.mystrixstudio.points.client.AnimatedLeaderboardRow;
import com.mystrixstudio.points.client.LeaderboardLayout;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

final class LeaderboardLayoutJUnitTest {
    @Test void originalTemplateDimensionsAndEmptyState() {
        assertEquals(158, LeaderboardLayout.ROW_W);
        assertEquals(30, LeaderboardLayout.ROW_H);
        assertEquals(180, LeaderboardLayout.LOGO_W);
        assertEquals(LeaderboardLayout.HEADER_H, LeaderboardLayout.height(0, 2));
        assertEquals(LeaderboardLayout.HEADER_H + 5 * 32 + LeaderboardLayout.FOOTER_H,
            LeaderboardLayout.height(5, 2));
    }

    @Test void smallScreenNeverOverflows() {
        float fit = LeaderboardLayout.fitScale(0.78f, 216, 240, LeaderboardLayout.height(5,2), 8);
        assertTrue(fit > 0f && fit <= 0.78f);
        assertTrue(LeaderboardLayout.WIDTH * fit <= 216 - 8);
    }

    @Test void animatedReorderingConvergesWithoutOvershoot() {
        AnimatedLeaderboardRow row = new AnimatedLeaderboardRow(100f, 18f, 13f);
        row.moveTo(35f);
        for (int i=0;i<200;i++) row.update(1f/60f);
        assertEquals(35f, row.y(), 0.06f);
        assertEquals(0f, row.slideX(), 0.06f);
        row.moveTo(110f);
        row.update(0.016f);
        assertTrue(row.y() >= 35f && row.y() < 110f);
    }
}
