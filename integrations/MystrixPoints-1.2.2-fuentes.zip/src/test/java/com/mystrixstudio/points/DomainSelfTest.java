package com.mystrixstudio.points;

import com.mystrixstudio.points.api.PointsApi.Game;
import com.mystrixstudio.points.core.MatchRegistry;
import com.mystrixstudio.points.core.PotatoScoring;
import java.util.*;

/** Dependency-free domain regression checks: java -ea -cp build/manual-classes com.mystrixstudio.points.DomainSelfTest */
public final class DomainSelfTest {
    public static void main(String[] args) {
        check(PotatoScoring.score(0,20)==10,"potato winner");
        check(PotatoScoring.score(1,20)==5,"potato second");
        check(PotatoScoring.score(2,20)==3,"potato third");
        check(PotatoScoring.score(4,20)==2,"potato top quarter");
        check(PotatoScoring.score(9,20)==1,"potato top half");
        check(PotatoScoring.score(10,20)==0,"potato others");
        check(PotatoScoring.score(0,1)==10,"single player");
        var registry=new MatchRegistry();
        var players=new LinkedHashSet<UUID>();
        for(int i=0;i<140;i++) players.add(UUID.randomUUID());
        var match=registry.begin(Game.BATTLEROYALE,UUID.randomUUID(),players,Map.of());
        UUID player=players.iterator().next();
        match.requirePlayer(player);
        registry.invalidatePlayer(player);
        boolean rejected=false;
        try { match.requirePlayer(player); } catch(IllegalArgumentException ok) { rejected=true; }
        check(rejected,"reset participant invalidation");
        var overflow=new HashSet<>(players);overflow.add(UUID.randomUUID());
        rejected=false;
        try { registry.begin(Game.BATTLEROYALE,UUID.randomUUID(),overflow,Map.of()); }
        catch(IllegalArgumentException ok) { rejected=true; }
        check(rejected,"140 player ceiling");
        var flash=new MatchRegistry();
        var f=flash.begin(Game.FLASHGAME,UUID.randomUUID(),players,Map.of("7",Set.of(players.iterator().next())));
        check(f.teams.get("7").size()==1,"team snapshot");
        f.close();rejected=false;
        try { f.requireActive(); }catch(IllegalStateException ok){rejected=true;}
        check(rejected,"cancelled game");
        System.out.println("DOMAIN TESTS PASSED (11 assertions)");
    }
    private static void check(boolean yes,String name) { if(!yes) throw new AssertionError(name); }
}
