package com.mystrixstudio.points;

import com.mystrixstudio.points.scoreboard.BoardSnapshot;
import java.util.*;

public final class BoardSnapshotSelfTest {
    public static void main(String[] args) {
        UUID a=UUID.randomUUID(), b=UUID.randomUUID(), c=UUID.randomUUID();
        var data=BoardSnapshot.fromRows("season-2",List.of(
            new BoardSnapshot.BalanceRow(a,"A","battleroyale",12),
            new BoardSnapshot.BalanceRow(a,"A","flashgame",10),
            new BoardSnapshot.BalanceRow(b,"B","flashgame",10),
            new BoardSnapshot.BalanceRow(c,"C","mystrixpotato",5)
        ),5);
        check(data.category("global").top().getFirst().playerId().equals(a),"global order");
        check(data.category("global").players().get(a).points()==22,"global aggregate");
        check(data.category("flashgame").players().get(b).points()==10,"game points");
        check(data.category("battleroyale").players().get(b)==null,"no game entry");
        check(data.category("mystrixpotato").players().get(c).rank()==1,"potato rank");
        check(data.categories().size()==4,"all scopes");
        System.out.println("SCOREBOARD DOMAIN TESTS PASSED");
    }
    private static void check(boolean pass,String message) {
        if(!pass)throw new AssertionError(message);
    }
}
