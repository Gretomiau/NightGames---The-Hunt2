# MystrixPoints 1.2.0 — Leaderboards compactos

Esta version reconstruye el **HUD** con el modelo de presentacion del `template-1.0.0.zip` aportado por el usuario. El motor de puntos, SQLite, API de integracion, comandos, resets y temporadas permanecen. Se mantiene el arte de THE HUNT 2 (morado/cian), no el tema Gulag del template.

## Cambios reales

- Filas de **158 × 30 unidades** y logotipo de **180 × 34**, escalados independientemente (la version previa tenia un panel de 252 × 343).
- Anclaje **a la derecha**, centrado verticalmente y adaptable al tamano de la ventana; por defecto escala **0.78**.
- Oculta filas vacias y, sin clasificados, dibuja solo logotipo/categoria.
- Filas animadas individualmente al entrar o cambiar posiciones, identificadas por UUID.
- Cabezas renderizadas desde el cache de skins de jugadores conectados; para jugadores offline, muestra el icono de calavera como fallback sin bloquear el render ni consultar una API remota.
- Configuracion visual: `scale`, `logoScale`, `textScale`, `footerScale`, `rowSpacing`, `maxRows`, `marginRight`, `offsetY`, `renderHeads` en `config/mystrixpoints-hud.json`.
- Servidor autoritativo: `/points scoreboard showall`, `/points scoreboard hideall`, `/points scoreboard status`; no se registro atajo de ocultacion ni permitimos anular la politica desde la configuracion cliente. F9 solo cambia el tablero.
- Identidades UUID incluidas en el paquete de clasificacion. **Cliente y servidor deben actualizarse juntos a 1.2.0**, cambia el formato de `hud_snapshot`.

## Compilacion

En Windows (JDK 21 instalado):

```powershell
.\gradlew.bat --no-daemon clean build
```

Se espera que el JAR quede en `build/libs/`. Hay pruebas de dominio, leaderboard/animacion y persistencia. Este entorno no ha podido verificar un build completo contra Fabric y Minecraft; no afirmamos que el proyecto este compilado en produccion.

## Una nota sobre 'identico'

Se replico la estructura, medidas y el comportamiento de filas animadas, adaptado al HUD propio y a MystrixPoints. No se redistribuye el codigo compilado de BetterLeaderboards ni sus dependencias internas. Algunas caracteristicas del template como personalizar por servidor cada columna o traer skins de jugadores offline via perfil remoto no forman parte de esta implementacion.
