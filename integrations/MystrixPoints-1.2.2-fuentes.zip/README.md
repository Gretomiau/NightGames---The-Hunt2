# MystrixPoints 1.0.0 — Fabric 1.21.1 / Java 21

Motor autoritativo de puntuación para **MystrixStudio**. Proyecto Gradle basado en la plantilla entregada.

## Qué incluye

- API pública de Java 21: `PointsApi` + `PointsAccess` (solo servidor, **sin networking de cliente para conceder puntos**).
- Sesiones con roster inmutable, límite de **140 participantes en BattleRoyale**.
- BattleRoyale: **+1** por eliminación oficialmente confirmada con cambio a espectador; **+10** adicionales al ganador.
- Flashgame: **+10** a cada miembro elegible del equipo clasificado, una vez por equipo por partida.
- MystrixPotato: reparto según posición final: **10, 5, 3, 2, 1 o 0**, condicionado a partida terminada con ganador.
- Otros mods confiables: `PointsAccess.get().externalAward("modid", eventId, Map.of(uuid, cantidad))`.
- SQLite WAL y `synchronous=FULL`, cola acotada de 8192 operaciones y **un solo escritor**; ejecutor separado para lecturas.
- Ledger de puntos, saldo materializado por mod, registro persistente de eventos idempotentes, temporadas, archivo por temporada y auditoría de reseteos.
- Base de datos: `config/mystrixpoints/points.sqlite`.
- Las operaciones de almacenamiento son asíncronas. No se introducen ticks periódicos.

## Compilar

Desde esta carpeta, en Windows con Java 21 y acceso a Maven/Gradle:

```powershell
.\gradlew.bat --no-daemon clean build
```

Linux/macOS: `./gradlew --no-daemon clean build`.

**IMPORTANTE:** En el entorno de preparación del ZIP no se pudo descargar `gradle-9.7.1-bin.zip` (sin resolución DNS de services.gradle.org). **No se entrega ni se afirma haber compilado un JAR de mod ejecutable.** El proyecto incluye Gradle Wrapper, fuentes Java, dependencias Gradle y metadata Fabric, listo para compilar en un entorno con red.

El JAR resultante se coloca **solo en el servidor** (o en la instancia que ejecute servidor integrado). **No es necesario instalar un JAR cliente** para usar los comandos. Para overlays a futuro se podrá distribuir un cliente opcional.

## Comandos

Consultas:

```
/points
/points get <nombre-o-uuid>
/points top
/points top battleroyale
/points season
```

Administración (requiere permisos nivel 4):

```
/points add <nombre-o-uuid> <cantidad>
/points remove <nombre-o-uuid> <cantidad>
/points set <nombre-o-uuid> <cantidad>
/points reset <nombre-o-uuid>
/points resetuuid <uuid>
/points resetall confirm
/points resetoffline confirm
/points resetonline confirm
/points resetgame battleroyale confirm
/points resetgame flashgame confirm
/points resetgame mystrixpotato confirm
/points resetgame all confirm
/points season new <id> confirm
```

Las operaciones add/remove/set modifican **el total global**, no solo la columna de administración. Los jugadores offline se reconocen por el UUID o por el último nombre **registrado en esta base**. Para nombres ambiguos reutilizados se exige UUID. Se recomienda hacer backup de los archivos SQLite en apagado antes de reseteos generales.

## API de las partidas

```java
PointsApi api = PointsAccess.get();
UUID partida = UUID.randomUUID();
api.beginMatch(PointsApi.Game.BATTLEROYALE, partida, participantesActivos, Map.of());
api.battleRoyaleKill(partida, victima, atacante, true); // SOLO después del cambio legítimo a SPECTATOR
api.battleRoyaleVictory(partida, ganador);

api.beginMatch(PointsApi.Game.FLASHGAME, otraPartida, todos, equipos);
api.flashgameQualified(otraPartida, "7");

api.beginMatch(PointsApi.Game.MYSTRIXPOTATO, otraPartida3, todos, Map.of());
api.potatoFinished(otraPartida3, posicionesDePrimeroAUltimo);

api.externalAward("mimod", "evento:UUID-estable", Map.of(uuid, 50L));
```

`CompletionStage` confirma APPLY / DUPLICATE cuando la transacción SQLite termina. Los errores no son éxitos; hay que registrar/reintentar eventos fallidos manteniendo el mismo identificador. Los minijuegos modificados incluyen logging. **Si el servidor se cae antes de que un evento se pueda guardar, el minijuego deberá recuperarlo y reemitirlo con el mismo ID para no perder la recompensa**: esta versión no proporciona una cola durable en disco anterior a SQLite.

## Integraciones por separado

1. `BattleRoyale-MystrixPoints-Source.zip`: cambios en `BattleRoyaleManager`, API `compileOnly`, dependencia server-side y hooks de RUNNING / eliminación / victoria / cancelación.
2. `Flashgame-MystrixPoints-Source.zip`: cambios en `TeamSystem`, API `compileOnly`, dependencia server-side y hooks de inicio / clasificación / reinicio.
3. `MystrixPotato-MystrixPoints-LegacyPatch.zip`: cambios en el `PotatoEventManager` recuperado, API `compileOnly`. **Este proyecto original no contiene todas las fuentes necesarias para generar su JAR 1.4.7 desde Java**. Las clases modificadas no llegan al JAR existente mediante `packageClientServer`, porque ese script reempaqueta bytecode anterior; aún requiere reconstrucción completa o parche de bytecode auditado.

> El archivo `mystrixpoints-api-1.0.0-compileOnly.jar` es exclusivamente para compilar otras integraciones. No se instala en la carpeta `mods` ni reemplaza al JAR compilado del mod central.

## Seguridad y rendimiento

- Escribir en SQLite desde el hilo principal está prohibido; las llamadas del API solo envían mensajes inmutables a la cola.
- Una transacción verifica la clave `(game_id, match_id, event_id)` y modifica el saldo y el ledger; si una operación falla, hace rollback.
- Flashgame envía todo el equipo en una sola transacción. No se permiten cantidades superiores a 10 por destinatario en los tres minijuegos.
- La API externa para mods confiables admite 1..10000 por destinatario y hasta 2048 destinatarios por evento.
- Resetall/resetgame/temporada invalidan todas las sesiones en su alcance antes de encolar el reseteo. ResetPlayer/online/offline descartan receptores antiguos. Las operaciones pendientes encoladas **antes** de un reseteo se ejecutan antes de él y quedan reseteadas; posteriores a la invalidación se rechazan.
- Un fallo de disco o cierre no limpio puede afectar operaciones aún no confirmadas. Hacer pruebas de recuperación con resultados durables de minijuego.

## Validación realizada

- Java 21: `javac --release 21` sobre `api/`, `core/`, `storage/` — **PASS**.
- DomainSelfTest: 11 aserciones (puntuación, 140 jugadores, reset e inmovilidad de sesiones) — **PASS**.
- Sintaxis del adaptador Java Fabric comprobada con stubs locales — **PASS, no equivale a compilar contra Minecraft/Fabric reales**.
- SQL DDL, restricción de duplicados, UPSERT de saldos ejercitados mediante Python `sqlite3` — **PASS**.
- Gradle + mod Fabric real, mods de terceros y prueba en servidor con 140 usuarios — **NO EJECUTADOS** en este entorno.


## Scoreboard HUD sci-fi (v1.1 source)

- Reference art: `scoreboard.zip` supplied by the project owner. Pixel-art frames and The Hunt 2 logo are bundled and cropped for a compact on-screen leaderboard. Not dependent on the BetterLeaderboards compiled template.
- Client: install the **same** MystrixPoints universal Fabric JAR on the client to enable the overlay. Server can run on dedicated machines; no client classes loaded by common initializer.
- The client overlay shows TOP 5 + your position/points. Visibility is controlled by the server using `/points scoreboard showall` and `/points scoreboard hideall` (OP level 4). Players cannot toggle the HUD with F8. **F9** switches Global / BattleRoyale / Flashgame / MystrixPotato.
- Layout settings: `config/mystrixpoints-hud.json` (client); `scale`, `marginRight`, `marginTop`, `visible`, `defaultScope`.
- No vanilla score objectives or scoreboard teams are modified. Works alongside team systems.
- Updates are triggered by SQLite commits and player joins; broadcasts are batched by 600ms. **No server tick callbacks**. When clients lack the mod, nothing is sent.
- The HUD does not grant points or take client-submitted scores; server alone owns the balances.
- Important: this ZIP is **source code**. Build locally with `gradlew.bat --no-daemon clean build` and verify Fabric runtime before production.


## 1.2.0 — BetterLeaderboards-like compact HUD

Render compactos 158x30, logo independiente 180x34, filas animadas por UUID y filas vacias ocultas. Detalles en `LEEME-LEADERBOARDS-1.2.0.md`. **Actualizar JAR servidor y cliente juntos**: el payload HUD ahora incluye UUID.
