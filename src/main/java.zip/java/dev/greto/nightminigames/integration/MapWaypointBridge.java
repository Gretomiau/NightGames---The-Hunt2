package dev.greto.nightminigames.integration;

import dev.greto.nightminigames.NightminigamesMod;
import dev.greto.nightminigames.module.ModuleSystem;
import dev.greto.nightminigames.persistence.WorldStructureJson;
import dev.greto.nightminigames.team.TeamBinding;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.scores.PlayerTeam;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public final class MapWaypointBridge {
    private static boolean initialized;

    private MapWaypointBridge() {
    }

    public static void initialize() {
        if (initialized) {
            return;
        }
        initialized = true;
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> server.execute(() -> addOnlineMember(server, handler.player)));
    }

    public static boolean available() {
        return FabricLoader.getInstance().isModLoaded("mapmitryx");
    }

    public static void refreshGroups(MinecraftServer server) {
        if (!available()) {
            return;
        }
        for (String team : ModuleSystem.TEAMS) {
            replaceGroup(server, team);
        }
    }

    private static void replaceGroup(MinecraftServer server, String team) {
        if (!available()) {
            return;
        }
        try {
            Class<?> groups = Class.forName("com.mapmitryx.api.MytrixWaypointGroups");
            List<UUID> members = new ArrayList<>();
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                PlayerTeam actual = server.getScoreboard().getPlayersTeam(player.getScoreboardName());
                if (actual != null && team.equals(actual.getName())) {
                    members.add(player.getUUID());
                }
            }
            groups.getMethod("replaceOnlineMembers", MinecraftServer.class, String.class, java.util.Collection.class)
                .invoke(null, server, group(team), members);
        } catch (ReflectiveOperationException | RuntimeException exception) {
            NightminigamesMod.LOGGER.warn("[Nightminigames] No se pudo sincronizar el grupo de MapaMystrix {}", team, exception);
        }
    }

    private static void addOnlineMember(MinecraftServer server, ServerPlayer player) {
        if (!available()) {
            return;
        }
        PlayerTeam membership = server.getScoreboard().getPlayersTeam(player.getScoreboardName());
        if (membership == null || !TeamBinding.valid(membership.getName())) {
            return;
        }
        try {
            Class.forName("com.mapmitryx.api.MytrixWaypointGroups")
                .getMethod("addMember", MinecraftServer.class, String.class, UUID.class)
                .invoke(null, server, group(membership.getName()), player.getUUID());
        } catch (ReflectiveOperationException | RuntimeException exception) {
            NightminigamesMod.LOGGER.warn("[Nightminigames] No se pudo actualizar MapaMystrix al conectar {}", player.getGameProfile().getName(), exception);
        }
    }

    public static boolean publish(MinecraftServer server, String team, List<WorldStructureJson.KnownKey> known) {
        if (!available()) {
            return false;
        }
        try {
            replaceGroup(server, team);
            Class<?> api = Class.forName("com.mapmitryx.api.MytrixWaypoints");
            Class<?> builderClass = Class.forName("com.mapmitryx.api.MytrixWaypoints$Builder");
            Method remove = api.getMethod("remove", MinecraftServer.class, String.class);
            Method snapshot = api.getMethod("snapshot");
            String prefix = prefix(team);
            List<String> previous = new ArrayList<>();
            for (Object marker : (List<?>) snapshot.invoke(null)) {
                String id = (String) marker.getClass().getMethod("id").invoke(marker);
                if (id.startsWith(prefix)) {
                    previous.add(id);
                }
            }
            for (String id : previous) {
                remove.invoke(null, server, id);
            }
            Method builder = api.getMethod("builder", String.class, String.class, int.class, int.class, int.class);
            Method name = builderClass.getMethod("name", String.class);
            Method image = builderClass.getMethod("image", String.class);
            Method size = builderClass.getMethod("size", int.class);
            Method category = builderClass.getMethod("category", String.class);
            Method color = builderClass.getMethod("color", int.class);
            Method group = builderClass.getMethod("group", String.class);
            Method publish = builderClass.getMethod("publish", MinecraftServer.class);
            for (WorldStructureJson.KnownKey key : known) {
                if (key.collected()) {
                    continue;
                }
                String id = prefix + UUID.nameUUIDFromBytes((key.dimension() + ":" + key.pos().asLong() + ":" + key.color())
                    .getBytes(StandardCharsets.UTF_8)).toString().replace("-", "");
                Object point = builder.invoke(null, id, key.dimension(), key.pos().getX(), key.pos().getY(), key.pos().getZ());
                name.invoke(point, "LLAVE " + key.color().toUpperCase() + " · " + team.toUpperCase());
                image.invoke(point, "objective");
                size.invoke(point, 32);
                category.invoke(point, "nightminigames");
                color.invoke(point, 0xFF000000 | colorOf(key.color()));
                group.invoke(point, group(team));
                publish.invoke(point, server);
            }
            return true;
        } catch (ReflectiveOperationException | RuntimeException exception) {
            Throwable cause = exception instanceof InvocationTargetException target ? target.getTargetException() : exception;
            NightminigamesMod.LOGGER.error("[Nightminigames] No se pudieron publicar las llaves en MapaMystrix", cause);
            return false;
        }
    }

    private static int colorOf(String color) {
        return switch (color) {
            case "blue" -> 0x4C92F5;
            case "yellow" -> 0xE9C644;
            case "red" -> 0xF25A5A;
            case "green" -> 0x50CB80;
            default -> 0x55DDFF;
        };
    }

    private static String prefix(String team) {
        return "nmkey_" + team + "_";
    }

    private static String group(String team) {
        return "nm_" + team;
    }
}
